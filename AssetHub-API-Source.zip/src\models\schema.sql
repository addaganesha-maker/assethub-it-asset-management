-- ─── Extensions ───────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── Users ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id              SERIAL PRIMARY KEY,
    email           VARCHAR(255) UNIQUE NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,
    full_name       VARCHAR(128),
    role            VARCHAR(16) NOT NULL DEFAULT 'viewer'
                    CHECK (role IN ('admin','technician','viewer')),
    ad_employee_id  VARCHAR(64),
    auth_provider   VARCHAR(24) NOT NULL DEFAULT 'local',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    last_login      TIMESTAMPTZ
);

-- ─── Agent API keys ──────────────────────────────────────

CREATE TABLE IF NOT EXISTS agent_keys (
    id              SERIAL PRIMARY KEY,
    key_hash        VARCHAR(255) NOT NULL,
    label           VARCHAR(128),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Assets ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS staff_users (
    id              BIGSERIAL PRIMARY KEY,
    employee_id     VARCHAR(64) UNIQUE NOT NULL,
    full_name       VARCHAR(160) NOT NULL,
    email           VARCHAR(255) UNIQUE NOT NULL,
    phone           VARCHAR(64),
    department      VARCHAR(128),
    division        VARCHAR(128),
    job_title       VARCHAR(128),
    manager         VARCHAR(160),
    location        VARCHAR(128),
    hire_date       DATE,
    resignation_date DATE,
    status          VARCHAR(16) NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','inactive','on_leave','resigned')),
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE staff_users ADD COLUMN IF NOT EXISTS division VARCHAR(128);
ALTER TABLE staff_users ADD COLUMN IF NOT EXISTS resignation_date DATE;
ALTER TABLE staff_users DROP CONSTRAINT IF EXISTS staff_users_status_check;
ALTER TABLE staff_users ADD CONSTRAINT staff_users_status_check
    CHECK (status IN ('active','inactive','on_leave','resigned'));

ALTER TABLE users ADD COLUMN IF NOT EXISTS ad_employee_id VARCHAR(64);
ALTER TABLE users ADD COLUMN IF NOT EXISTS auth_provider VARCHAR(24) NOT NULL DEFAULT 'local';
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_ad_employee_id
    ON users(ad_employee_id) WHERE ad_employee_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_staff_users_name ON staff_users(full_name);
CREATE INDEX IF NOT EXISTS idx_staff_users_department ON staff_users(department);

CREATE TABLE IF NOT EXISTS assets (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    asset_tag       VARCHAR(32) UNIQUE,
    hostname        VARCHAR(255) NOT NULL,
    asset_type      VARCHAR(32) NOT NULL DEFAULT 'workstation',
    os_name         VARCHAR(128),
    os_version      VARCHAR(64),
    os_build        VARCHAR(64),
    architecture    VARCHAR(16),
    ip_address      VARCHAR(64),
    mac_address     VARCHAR(64) UNIQUE,
    cpu_model       VARCHAR(160),
    cpu_cores       INTEGER,
    ram_gb          NUMERIC(6,2),
    disk_total_gb   NUMERIC(8,2),
    disk_free_gb    NUMERIC(8,2),
    storage_devices JSONB NOT NULL DEFAULT '[]'::jsonb,
    network_adapters JSONB NOT NULL DEFAULT '[]'::jsonb,
    monitor_devices JSONB NOT NULL DEFAULT '[]'::jsonb,
    gpu_model       VARCHAR(160),
    serial_number   VARCHAR(128),
    manufacturer    VARCHAR(128),
    model           VARCHAR(128),
    purchase_date   DATE,
    warranty_end_date DATE,
    warranty_checked_at TIMESTAMPTZ,
    bios_version    VARCHAR(64),
    system_uuid     VARCHAR(64),
    system_type     VARCHAR(64),
    logged_in_user  VARCHAR(255),
    logged_in_domain VARCHAR(255),
    domain_name     VARCHAR(255),
    domain_joined   BOOLEAN NOT NULL DEFAULT FALSE,
    workgroup_name  VARCHAR(255),
    outlook_email   VARCHAR(255),
    onedrive_email  VARCHAR(255),
    user_session_seen_at TIMESTAMPTZ,
    agent_version    VARCHAR(64),
    agent_installed_at TIMESTAMPTZ,
    latitude        DOUBLE PRECISION,
    longitude       DOUBLE PRECISION,
    location_accuracy_m DOUBLE PRECISION,
    location_updated_at TIMESTAMPTZ,
    uptime_seconds  BIGINT,
    status          VARCHAR(16) DEFAULT 'active'
                    CHECK (status IN ('active','offline','retired')),
    assigned_user   VARCHAR(128),
    assigned_user_id BIGINT REFERENCES staff_users(id) ON DELETE SET NULL,
    lifecycle_status VARCHAR(16) NOT NULL DEFAULT 'stock'
                    CHECK (lifecycle_status IN ('stock','issued')),
    stock_section   VARCHAR(16) NOT NULL DEFAULT 'main'
                    CHECK (stock_section IN ('main','spare','standby')),
    department      VARCHAR(128),
    location        VARCHAR(128),
    tags            JSONB DEFAULT '[]'::jsonb,
    last_seen       TIMESTAMPTZ DEFAULT NOW(),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS asset_tag_catalog (
    id          BIGSERIAL PRIMARY KEY,
    name        VARCHAR(64) NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS asset_location_history (
    id              BIGSERIAL PRIMARY KEY,
    asset_id        UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
    latitude        DOUBLE PRECISION NOT NULL CHECK (latitude BETWEEN -90 AND 90),
    longitude       DOUBLE PRECISION NOT NULL CHECK (longitude BETWEEN -180 AND 180),
    accuracy_m      DOUBLE PRECISION,
    captured_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_asset_location_history_asset_time
    ON asset_location_history(asset_id, captured_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS asset_tag_catalog_name_lower_idx
    ON asset_tag_catalog (LOWER(name));

CREATE INDEX IF NOT EXISTS idx_assets_hostname ON assets(hostname);
CREATE INDEX IF NOT EXISTS idx_assets_status   ON assets(status);
CREATE INDEX IF NOT EXISTS idx_assets_last_seen ON assets(last_seen DESC);

CREATE TABLE IF NOT EXISTS network_discoveries (
    id                  BIGSERIAL PRIMARY KEY,
    observer_asset_id   UUID REFERENCES assets(id) ON DELETE CASCADE,
    subnet              CIDR NOT NULL,
    ip_address          INET NOT NULL,
    mac_address         VARCHAR(32),
    hostname            VARCHAR(255),
    first_seen          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (observer_asset_id, ip_address)
);

CREATE INDEX IF NOT EXISTS idx_network_discoveries_seen
    ON network_discoveries(last_seen DESC);
CREATE UNIQUE INDEX IF NOT EXISTS idx_network_discoveries_host_ip
    ON network_discoveries(ip_address) WHERE observer_asset_id IS NULL;
CREATE INDEX IF NOT EXISTS idx_assets_lifecycle_status ON assets(lifecycle_status);

CREATE TABLE IF NOT EXISTS asset_assignment_history (
    id              BIGSERIAL PRIMARY KEY,
    asset_id        UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
    event_type      VARCHAR(16) NOT NULL CHECK (event_type IN ('stocked','issued','returned')),
    from_user_id    BIGINT REFERENCES staff_users(id) ON DELETE SET NULL,
    to_user_id      BIGINT REFERENCES staff_users(id) ON DELETE SET NULL,
    from_user_name  VARCHAR(160),
    to_user_name    VARCHAR(160),
    performed_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    notes           TEXT,
    policy_snapshot JSONB,
    occurred_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_assignment_history_asset_time
    ON asset_assignment_history(asset_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_assignment_history_event
    ON asset_assignment_history(event_type, occurred_at DESC);

-- ─── Installed software ──────────────────────────────────
CREATE TABLE IF NOT EXISTS installed_software (
    id              BIGSERIAL PRIMARY KEY,
    asset_id        UUID REFERENCES assets(id) ON DELETE CASCADE,
    software_name   VARCHAR(255) NOT NULL,
    version         VARCHAR(64),
    publisher       VARCHAR(160),
    install_date    DATE,
    product_code    VARCHAR(38),
    install_path    TEXT,
    is_authorized   BOOLEAN DEFAULT TRUE,
    detected_at     TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (asset_id, software_name, version)
);

CREATE INDEX IF NOT EXISTS idx_software_asset ON installed_software(asset_id);
CREATE INDEX IF NOT EXISTS idx_software_name  ON installed_software(software_name);
ALTER TABLE installed_software ADD COLUMN IF NOT EXISTS product_code VARCHAR(38);

-- Admin-managed Windows MSI/EXE deployment packages and per-device jobs.
CREATE TABLE IF NOT EXISTS software_deployment_packages (
    id              UUID PRIMARY KEY,
    name            VARCHAR(200) NOT NULL,
    version         VARCHAR(64) NOT NULL,
    original_name   VARCHAR(255) NOT NULL,
    storage_name    VARCHAR(80) NOT NULL UNIQUE,
    package_type    VARCHAR(16) NOT NULL DEFAULT 'msi' CHECK (package_type IN ('msi','exe')),
    product_code    VARCHAR(38),
    install_args    JSONB NOT NULL DEFAULT '[]'::jsonb,
    sha256          CHAR(64) NOT NULL,
    size_bytes      BIGINT NOT NULL,
    uploaded_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS software_deployment_jobs (
    id              UUID PRIMARY KEY,
    package_id      UUID REFERENCES software_deployment_packages(id) ON DELETE RESTRICT,
    asset_id        UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
    action           VARCHAR(16) NOT NULL CHECK (action IN ('install','uninstall')),
    software_name    VARCHAR(200),
    software_version VARCHAR(64),
    product_code     VARCHAR(38),
    status           VARCHAR(16) NOT NULL DEFAULT 'queued'
                     CHECK (status IN ('queued','running','succeeded','failed')),
    requested_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    exit_code        INTEGER,
    output           TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    started_at       TIMESTAMPTZ,
    completed_at     TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_software_jobs_asset_queue
    ON software_deployment_jobs(asset_id, status, created_at);
CREATE INDEX IF NOT EXISTS idx_software_jobs_created
    ON software_deployment_jobs(created_at DESC);

-- ─── Time-series metrics ─────────────────────────────────
CREATE TABLE IF NOT EXISTS asset_metrics (
    time            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    asset_id        UUID REFERENCES assets(id) ON DELETE CASCADE,
    cpu_percent     NUMERIC(5,2),
    ram_percent     NUMERIC(5,2),
    ram_used_gb     NUMERIC(6,2),
    disk_percent    NUMERIC(5,2),
    disk_free_gb    NUMERIC(8,2),
    net_rx_bytes    BIGINT,
    net_tx_bytes    BIGINT,
    process_count   INTEGER,
    logged_user     VARCHAR(128)
);

CREATE INDEX IF NOT EXISTS idx_metrics_asset_time
    ON asset_metrics(asset_id, time DESC);

-- Optional: convert to hypertable if TimescaleDB is available
-- SELECT create_hypertable('asset_metrics', 'time', if_not_exists => TRUE);

-- ─── Alerts ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS alerts (
    id              BIGSERIAL PRIMARY KEY,
    asset_id        UUID REFERENCES assets(id) ON DELETE CASCADE,
    rule_name       VARCHAR(128) NOT NULL,
    severity        VARCHAR(16) CHECK (severity IN ('info','warning','critical')),
    message         TEXT,
    metric_value    NUMERIC,
    is_resolved     BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    resolved_at     TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_alerts_asset ON alerts(asset_id);
CREATE INDEX IF NOT EXISTS idx_alerts_open  ON alerts(is_resolved, created_at DESC);

-- ─── Alert rules ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS alert_rules (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(128) UNIQUE NOT NULL,
    metric          VARCHAR(64) NOT NULL,      -- cpu_percent, ram_percent, disk_percent
    operator        VARCHAR(8) NOT NULL,       -- '>', '<', '>=', '<='
    threshold       NUMERIC NOT NULL,
    severity        VARCHAR(16) NOT NULL DEFAULT 'warning',
    duration_sec    INTEGER DEFAULT 0,
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO alert_rules (name, metric, operator, threshold, severity, duration_sec)
VALUES
  ('CPU Critical',  'cpu_percent',  '>', 90, 'critical', 300),
  ('CPU High',      'cpu_percent',  '>', 80, 'warning',  300),
  ('RAM Critical',  'ram_percent',  '>', 92, 'critical', 300),
  ('Disk Low',      'disk_percent', '>', 90, 'warning',  0),
  ('Disk Critical', 'disk_percent', '>', 96, 'critical', 0)
ON CONFLICT (name) DO NOTHING;

-- ─── Audit log ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_log (
    id              BIGSERIAL PRIMARY KEY,
    user_id         INTEGER REFERENCES users(id),
    action          VARCHAR(64) NOT NULL,
    entity_type     VARCHAR(64),
    entity_id       VARCHAR(64),
    payload         JSONB,
    ip_address      VARCHAR(64),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Employee directory records managed from the admin portal.
