import { query } from '../config/db.js';

export async function ensureOutlookJobsSchema() {
  await query(`
    CREATE TABLE IF NOT EXISTS outlook_draft_jobs (
      id UUID PRIMARY KEY,
      assignment_id BIGINT NOT NULL REFERENCES asset_assignment_history(id) ON DELETE CASCADE,
      requested_by INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      status VARCHAR(16) NOT NULL DEFAULT 'queued'
        CHECK (status IN ('queued', 'processing', 'opened', 'failed')),
      payload JSONB,
      error_message VARCHAR(500),
      attempts INTEGER NOT NULL DEFAULT 0,
      lease_expires_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      completed_at TIMESTAMPTZ
    );
    CREATE INDEX IF NOT EXISTS idx_outlook_draft_jobs_queue
      ON outlook_draft_jobs(status, created_at);
  `);
}
