import { pool } from '../config/db.js';

export async function ensureSoftwareDeploymentTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS software_deployment_packages (
      id UUID PRIMARY KEY,
      name VARCHAR(200) NOT NULL,
      version VARCHAR(64) NOT NULL,
      original_name VARCHAR(255) NOT NULL,
      storage_name VARCHAR(80) NOT NULL UNIQUE,
      package_type VARCHAR(16) NOT NULL DEFAULT 'msi' CHECK (package_type IN ('msi','exe')),
      product_code VARCHAR(38),
      install_args JSONB NOT NULL DEFAULT '[]'::jsonb,
      sha256 CHAR(64) NOT NULL,
      size_bytes BIGINT NOT NULL,
      uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS software_deployment_jobs (
      id UUID PRIMARY KEY,
      package_id UUID REFERENCES software_deployment_packages(id) ON DELETE RESTRICT,
      asset_id UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
      action VARCHAR(16) NOT NULL CHECK (action IN ('install','uninstall')),
      software_name VARCHAR(200),
      product_code VARCHAR(38),
      status VARCHAR(16) NOT NULL DEFAULT 'queued'
        CHECK (status IN ('queued','running','succeeded','failed')),
      requested_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      exit_code INTEGER,
      output TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      started_at TIMESTAMPTZ,
      completed_at TIMESTAMPTZ
    );
    CREATE INDEX IF NOT EXISTS idx_software_jobs_asset_queue
      ON software_deployment_jobs(asset_id, status, created_at);
    CREATE INDEX IF NOT EXISTS idx_software_jobs_created
      ON software_deployment_jobs(created_at DESC);
    ALTER TABLE installed_software ADD COLUMN IF NOT EXISTS product_code VARCHAR(38);
    ALTER TABLE software_deployment_packages
      ADD COLUMN IF NOT EXISTS package_type VARCHAR(16) NOT NULL DEFAULT 'msi',
      ADD COLUMN IF NOT EXISTS install_args JSONB NOT NULL DEFAULT '[]'::jsonb,
      ALTER COLUMN product_code DROP NOT NULL;
    ALTER TABLE software_deployment_jobs
      ALTER COLUMN package_id DROP NOT NULL,
      ADD COLUMN IF NOT EXISTS software_name VARCHAR(200),
      ADD COLUMN IF NOT EXISTS software_version VARCHAR(64),
      ADD COLUMN IF NOT EXISTS product_code VARCHAR(38);
  `);
}
