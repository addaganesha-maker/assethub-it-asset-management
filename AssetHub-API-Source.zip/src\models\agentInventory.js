import { query } from '../config/db.js';

export async function ensureAgentInventorySchema() {
  await query(`
    ALTER TABLE assets
      ADD COLUMN IF NOT EXISTS system_uuid VARCHAR(64),
      ADD COLUMN IF NOT EXISTS system_type VARCHAR(64),
      ADD COLUMN IF NOT EXISTS logged_in_user VARCHAR(255),
      ADD COLUMN IF NOT EXISTS logged_in_domain VARCHAR(255),
      ADD COLUMN IF NOT EXISTS domain_name VARCHAR(255),
      ADD COLUMN IF NOT EXISTS domain_joined BOOLEAN NOT NULL DEFAULT FALSE,
      ADD COLUMN IF NOT EXISTS workgroup_name VARCHAR(255),
      ADD COLUMN IF NOT EXISTS outlook_email VARCHAR(255),
      ADD COLUMN IF NOT EXISTS onedrive_email VARCHAR(255),
      ADD COLUMN IF NOT EXISTS user_session_seen_at TIMESTAMPTZ;
    ALTER TABLE assets
      ADD COLUMN IF NOT EXISTS agent_version VARCHAR(64),
      ADD COLUMN IF NOT EXISTS agent_installed_at TIMESTAMPTZ,
      ADD COLUMN IF NOT EXISTS latitude DOUBLE PRECISION,
      ADD COLUMN IF NOT EXISTS longitude DOUBLE PRECISION,
      ADD COLUMN IF NOT EXISTS location_accuracy_m DOUBLE PRECISION,
      ADD COLUMN IF NOT EXISTS location_updated_at TIMESTAMPTZ;
  `);
  await query(`
    ALTER TABLE assets
      ADD COLUMN IF NOT EXISTS lifecycle_status VARCHAR(16) NOT NULL DEFAULT 'stock'
        CHECK (lifecycle_status IN ('stock', 'issued')),
      ADD COLUMN IF NOT EXISTS stock_section VARCHAR(16) NOT NULL DEFAULT 'main'
        CHECK (stock_section IN ('main', 'spare', 'standby'));
    CREATE INDEX IF NOT EXISTS idx_assets_lifecycle_status
      ON assets(lifecycle_status);
    CREATE INDEX IF NOT EXISTS idx_assets_stock_section
      ON assets(stock_section);
  `);
  await query(`
    ALTER TABLE assets
      ADD COLUMN IF NOT EXISTS storage_devices JSONB NOT NULL DEFAULT '[]'::jsonb,
      ADD COLUMN IF NOT EXISTS network_adapters JSONB NOT NULL DEFAULT '[]'::jsonb;
    ALTER TABLE assets
      ADD COLUMN IF NOT EXISTS monitor_devices JSONB NOT NULL DEFAULT '[]'::jsonb;
  `);
  await query(`
    CREATE TABLE IF NOT EXISTS asset_location_history (
      id BIGSERIAL PRIMARY KEY,
      asset_id UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
      latitude DOUBLE PRECISION NOT NULL CHECK (latitude BETWEEN -90 AND 90),
      longitude DOUBLE PRECISION NOT NULL CHECK (longitude BETWEEN -180 AND 180),
      accuracy_m DOUBLE PRECISION,
      captured_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS idx_asset_location_history_asset_time
      ON asset_location_history(asset_id, captured_at DESC);

    CREATE TABLE IF NOT EXISTS network_discoveries (
      id BIGSERIAL PRIMARY KEY,
      observer_asset_id UUID REFERENCES assets(id) ON DELETE CASCADE,
      subnet CIDR NOT NULL,
      ip_address INET NOT NULL,
      mac_address VARCHAR(32),
      hostname VARCHAR(255),
      first_seen TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      last_seen TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE (observer_asset_id, ip_address)
    );
    CREATE INDEX IF NOT EXISTS idx_network_discoveries_seen
      ON network_discoveries(last_seen DESC);
    ALTER TABLE network_discoveries ALTER COLUMN observer_asset_id DROP NOT NULL;
    CREATE UNIQUE INDEX IF NOT EXISTS idx_network_discoveries_host_ip
      ON network_discoveries(ip_address) WHERE observer_asset_id IS NULL;
  `);
}
