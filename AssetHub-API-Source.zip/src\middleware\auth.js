import jwt from 'jsonwebtoken';
import { query } from '../config/db.js';

export async function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing token' });
  let identity;
  try {
    identity = jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    return res.status(401).json({ error: 'Invalid token' });
  }
  try {
    const { rows } = await query(
      'SELECT id, email, full_name, role, role_id, is_active FROM users WHERE id = $1',
      [identity.id]
    );
    if (!rows.length || !rows[0].is_active) return res.status(401).json({ error: 'Account is disabled' });
    req.user = { ...identity, ...rows[0] };
    next();
  } catch (error) {
    next(error);
  }
}

export function requirePermission(module, action = 'read') {
  return async (req, res, next) => {
    if (req.user?.role === 'admin') return next();
    try {
      const { rows } = await query('SELECT permissions FROM portal_roles WHERE id = $1', [req.user?.role_id]);
      if (!rows.length || !rows[0].permissions?.[module]?.[action]) {
        return res.status(403).json({ error: 'You do not have permission to perform this action.' });
      }
      next();
    } catch (error) {
      next(error);
    }
  };
}

export function requireAnyPermission(...checks) {
  return async (req, res, next) => {
    if (req.user?.role === 'admin') return next();
    try {
      const { rows } = await query('SELECT permissions FROM portal_roles WHERE id = $1', [req.user?.role_id]);
      const permissions = rows[0]?.permissions;
      if (!checks.some(([module, action = 'read']) => permissions?.[module]?.[action])) {
        return res.status(403).json({ error: 'You do not have permission to perform this action.' });
      }
      next();
    } catch (error) {
      next(error);
    }
  };
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    next();
  };
}

// Agent uses a shared API key from header
export async function requireAgentKey(req, res, next) {
  const key = req.headers['x-agent-key'];
  if (!key) return res.status(401).json({ error: 'Missing agent key' });
  const { query } = await import('../config/db.js');
  const bcrypt = await import('bcryptjs');

  const { rows } = await query(
    'SELECT id, key_hash FROM agent_keys WHERE is_active = TRUE'
  );
  for (const row of rows) {
    if (await bcrypt.default.compare(key, row.key_hash)) {
      req.agentKeyId = row.id;
      return next();
    }
  }
  return res.status(401).json({ error: 'Invalid agent key' });
}