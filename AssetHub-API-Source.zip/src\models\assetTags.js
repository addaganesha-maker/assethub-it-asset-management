import { query } from '../config/db.js';

export async function ensureAssetTagsSchema() {
  await query(`
    CREATE TABLE IF NOT EXISTS asset_tag_catalog (
      id BIGSERIAL PRIMARY KEY,
      name VARCHAR(64) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE UNIQUE INDEX IF NOT EXISTS asset_tag_catalog_name_lower_idx
      ON asset_tag_catalog (LOWER(name));
  `);
}
