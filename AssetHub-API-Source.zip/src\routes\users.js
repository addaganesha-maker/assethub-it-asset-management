import { Router } from 'express';
import { z } from 'zod';
import { pool, query } from '../config/db.js';
import { requireAuth, requireAnyPermission, requirePermission } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/error.js';

const router = Router();
const optionalText = (max) => z.string().trim().max(max).optional().default('');
const userSchema = z.object({
  employee_id: z.string().trim().min(1, 'Employee ID is required').max(64),
  full_name: z.string().trim().min(1, 'Full name is required').max(160),
  email: z.string().trim().email('Enter a valid work email').max(255).transform((value) => value.toLowerCase()),
  phone: optionalText(64),
  department: optionalText(128),
  division: optionalText(128),
  job_title: optionalText(128),
  location: optionalText(128),
  hire_date: z.union([z.string().date(), z.literal('')]).optional().default(''),
  resignation_date: z.union([z.string().date(), z.literal('')]).optional().default(''),
  status: z.enum(['active', 'inactive', 'on_leave', 'resigned']).optional().default('active'),
  notes: optionalText(4000),
}).transform((user) => ({
  ...user,
  status: user.resignation_date ? 'resigned' : user.status,
}));

const insertSql = `
  INSERT INTO staff_users
    (employee_id, full_name, email, phone, department, division, job_title, location, hire_date, resignation_date, status, notes)
  VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
  RETURNING *
`;

function valuesFor(user) {
  return [
    user.employee_id,
    user.full_name,
    user.email,
    user.phone || null,
    user.department || null,
    user.division || null,
    user.job_title || null,
    user.location || null,
    user.hire_date || null,
    user.resignation_date || null,
    user.status,
    user.notes || null,
  ];
}

function validationMessage(error) {
  return error.issues[0]?.message || 'Invalid user details';
}

router.use(requireAuth);

router.get('/', requireAnyPermission(['users', 'read'], ['assignments', 'read']), asyncHandler(async (req, res) => {
  const search = String(req.query.search || '').trim();
  const status = String(req.query.status || '').trim();
  const params = [];
  const where = [];

  if (search) {
    params.push(`%${search}%`);
    where.push(`(full_name ILIKE $${params.length} OR employee_id ILIKE $${params.length} OR email ILIKE $${params.length} OR department ILIKE $${params.length} OR division ILIKE $${params.length})`);
  }
  if (status && ['active', 'inactive', 'on_leave', 'resigned'].includes(status)) {
    params.push(status);
    where.push(`status = $${params.length}`);
  }

  const { rows } = await query(
    `SELECT * FROM staff_users ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY full_name ASC`,
    params
  );
  res.json({ data: rows, total: rows.length });
}));

router.post('/', requirePermission('users', 'write'), asyncHandler(async (req, res) => {
  const parsed = userSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: validationMessage(parsed.error) });

  try {
    const { rows } = await query(insertSql, valuesFor(parsed.data));
    res.status(201).json(rows[0]);
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Employee ID or email already exists.' });
    }
    throw error;
  }
}));

router.patch('/:id', requirePermission('users', 'write'), asyncHandler(async (req, res) => {
  if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid user ID.' });
  const parsed = userSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: validationMessage(parsed.error) });

  const user = parsed.data;
  try {
    const { rows } = await query(
      `UPDATE staff_users SET
         employee_id = $1, full_name = $2, email = $3, phone = $4,
         department = $5, division = $6, job_title = $7, location = $8,
         hire_date = $9, resignation_date = $10, status = $11, notes = $12,
         updated_at = NOW()
       WHERE id = $13
       RETURNING *`,
      [...valuesFor(user), req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'User not found.' });
    res.json(rows[0]);
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Employee ID or email already exists.' });
    }
    throw error;
  }
}));

router.post('/bulk', requirePermission('users', 'write'), asyncHandler(async (req, res) => {
  const rows = req.body?.users;
  if (!Array.isArray(rows) || rows.length === 0) {
    return res.status(400).json({ error: 'Upload at least one user row.' });
  }
  if (rows.length > 500) {
    return res.status(400).json({ error: 'Upload no more than 500 users at a time.' });
  }

  const client = await pool.connect();
  const errors = [];
  let imported = 0;
  let skipped = 0;

  try {
    await client.query('BEGIN');
    for (const [index, row] of rows.entries()) {
      const parsed = userSchema.safeParse(row);
      if (!parsed.success) {
        skipped += 1;
        errors.push({ row: index + 2, message: validationMessage(parsed.error) });
        continue;
      }

      const result = await client.query(
        `${insertSql.replace('RETURNING *', 'ON CONFLICT DO NOTHING RETURNING id')}`,
        valuesFor(parsed.data)
      );
      if (result.rowCount) {
        imported += 1;
      } else {
        skipped += 1;
        errors.push({ row: index + 2, message: 'Employee ID or email already exists.' });
      }
    }
    await client.query('COMMIT');
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }

  res.json({ imported, skipped, errors });
}));

router.delete('/bulk', requirePermission('users', 'delete'), asyncHandler(async (req, res) => {
  const ids = req.body?.ids;
  const isValidId = (id) => {
    if (Number.isSafeInteger(id)) return id > 0;
    if (typeof id !== 'string' || !/^[1-9]\d*$/.test(id)) return false;
    try {
      return BigInt(id) <= 9223372036854775807n;
    } catch {
      return false;
    }
  };
  if (!Array.isArray(ids) || ids.length === 0 || ids.length > 500
    || ids.some((id) => !isValidId(id))) {
    return res.status(400).json({ error: 'Select between 1 and 500 valid users to delete.' });
  }

  const uniqueIds = [...new Set(ids)];
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(
      'SELECT id, employee_id, full_name, email FROM staff_users WHERE id = ANY($1::bigint[]) FOR UPDATE',
      [uniqueIds]
    );
    if (rows.length !== uniqueIds.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'One or more selected users no longer exist. Refresh the list and try again.' });
    }

    await client.query('DELETE FROM staff_users WHERE id = ANY($1::bigint[])', [uniqueIds]);
    for (const user of rows) {
      await client.query(
        `INSERT INTO audit_log (user_id, action, entity_type, entity_id, payload, ip_address)
         VALUES ($1, 'user.deleted', 'staff_user', $2, $3::jsonb, $4)`,
        [req.user.id, String(user.id), JSON.stringify({ employee_id: user.employee_id, full_name: user.full_name, email: user.email }), req.ip]
      );
    }
    await client.query('COMMIT');
    res.json({ deleted: rows.length });
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}));

export default router;
