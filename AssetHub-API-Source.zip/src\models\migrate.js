import 'dotenv/config';
import { pool } from '../config/db.js';

try {
  await pool.query(`
    ALTER TABLE users
      ADD COLUMN IF NOT EXISTS ad_employee_id VARCHAR(64),
      ADD COLUMN IF NOT EXISTS auth_provider VARCHAR(24) NOT NULL DEFAULT 'local';
    CREATE UNIQUE INDEX IF NOT EXISTS idx_users_ad_employee_id
      ON users(ad_employee_id) WHERE ad_employee_id IS NOT NULL;

    CREATE TABLE IF NOT EXISTS staff_users (
      id BIGSERIAL PRIMARY KEY,
      employee_id VARCHAR(64) UNIQUE NOT NULL,
      full_name VARCHAR(160) NOT NULL,
      email VARCHAR(255) UNIQUE NOT NULL,
      phone VARCHAR(64),
      department VARCHAR(128),
      division VARCHAR(128),
      job_title VARCHAR(128),
      manager VARCHAR(160),
      location VARCHAR(128),
      hire_date DATE,
      resignation_date DATE,
      status VARCHAR(16) NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'inactive', 'on_leave', 'resigned')),
      notes TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    ALTER TABLE staff_users
      ADD COLUMN IF NOT EXISTS division VARCHAR(128),
      ADD COLUMN IF NOT EXISTS resignation_date DATE;
    ALTER TABLE staff_users DROP CONSTRAINT IF EXISTS staff_users_status_check;
    ALTER TABLE staff_users ADD CONSTRAINT staff_users_status_check
      CHECK (status IN ('active', 'inactive', 'on_leave', 'resigned'));
    CREATE INDEX IF NOT EXISTS idx_staff_users_name ON staff_users(full_name);
    CREATE INDEX IF NOT EXISTS idx_staff_users_department ON staff_users(department);

    ALTER TABLE assets
      ADD COLUMN IF NOT EXISTS assigned_user_id BIGINT
        REFERENCES staff_users(id) ON DELETE SET NULL,
      ADD COLUMN IF NOT EXISTS lifecycle_status VARCHAR(16) NOT NULL DEFAULT 'stock'
        CHECK (lifecycle_status IN ('stock', 'issued')),
      ADD COLUMN IF NOT EXISTS stock_section VARCHAR(16) NOT NULL DEFAULT 'main'
        CHECK (stock_section IN ('main', 'spare', 'standby'));

    CREATE INDEX IF NOT EXISTS idx_assets_lifecycle_status
      ON assets(lifecycle_status);
    CREATE INDEX IF NOT EXISTS idx_assets_stock_section
      ON assets(stock_section);

    CREATE TABLE IF NOT EXISTS asset_assignment_history (
      id BIGSERIAL PRIMARY KEY,
      asset_id UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
      event_type VARCHAR(16) NOT NULL
        CHECK (event_type IN ('stocked', 'issued', 'returned')),
      from_user_id BIGINT REFERENCES staff_users(id) ON DELETE SET NULL,
      to_user_id BIGINT REFERENCES staff_users(id) ON DELETE SET NULL,
      from_user_name VARCHAR(160),
      to_user_name VARCHAR(160),
      performed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      notes TEXT,
      occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS idx_assignment_history_asset_time
      ON asset_assignment_history(asset_id, occurred_at DESC);
    CREATE INDEX IF NOT EXISTS idx_assignment_history_event
      ON asset_assignment_history(event_type, occurred_at DESC);
    ALTER TABLE asset_assignment_history
      ADD COLUMN IF NOT EXISTS policy_snapshot JSONB;

    CREATE TABLE IF NOT EXISTS software_deployment_packages (
      id UUID PRIMARY KEY,
      name VARCHAR(200) NOT NULL,
      version VARCHAR(64) NOT NULL,
      original_name VARCHAR(255) NOT NULL,
      storage_name VARCHAR(80) NOT NULL UNIQUE,
      package_type VARCHAR(16) NOT NULL DEFAULT 'msi' CHECK (package_type IN ('msi','exe')),
      product_code VARCHAR(38),
      install_args JSONB NOT NULL DEFAULT '[]'::jsonb,
      sha256 CHAR(64) NOT NULL,
      size_bytes BIGINT NOT NULL,
      uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS software_deployment_jobs (
      id UUID PRIMARY KEY,
      package_id UUID NOT NULL REFERENCES software_deployment_packages(id) ON DELETE RESTRICT,
      asset_id UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
      action VARCHAR(16) NOT NULL CHECK (action IN ('install','uninstall')),
      status VARCHAR(16) NOT NULL DEFAULT 'queued'
        CHECK (status IN ('queued','running','succeeded','failed')),
      requested_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      exit_code INTEGER,
      output TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      started_at TIMESTAMPTZ,
      completed_at TIMESTAMPTZ
    );
    CREATE INDEX IF NOT EXISTS idx_software_jobs_asset_queue
      ON software_deployment_jobs(asset_id, status, created_at);
    CREATE INDEX IF NOT EXISTS idx_software_jobs_created
      ON software_deployment_jobs(created_at DESC);

    ALTER TABLE installed_software
      ADD COLUMN IF NOT EXISTS product_code VARCHAR(38);
    ALTER TABLE software_deployment_jobs
      ALTER COLUMN package_id DROP NOT NULL,
      ADD COLUMN IF NOT EXISTS software_name VARCHAR(200),
      ADD COLUMN IF NOT EXISTS software_version VARCHAR(64),
      ADD COLUMN IF NOT EXISTS product_code VARCHAR(38);
    ALTER TABLE software_deployment_packages
      ADD COLUMN IF NOT EXISTS package_type VARCHAR(16) NOT NULL DEFAULT 'msi',
      ADD COLUMN IF NOT EXISTS install_args JSONB NOT NULL DEFAULT '[]'::jsonb,
      ALTER COLUMN product_code DROP NOT NULL;

    UPDATE assets SET lifecycle_status = 'issued'
    WHERE assigned_user IS NOT NULL AND lifecycle_status = 'stock';

    UPDATE assets a SET assigned_user_id = s.id
    FROM staff_users s
    WHERE a.assigned_user_id IS NULL AND a.assigned_user IS NOT NULL
      AND LOWER(TRIM(a.assigned_user)) IN
        (LOWER(s.full_name), LOWER(s.email), LOWER(s.employee_id));

    INSERT INTO asset_assignment_history
      (asset_id, event_type, to_user_id, to_user_name, notes, occurred_at)
    SELECT a.id,
           CASE WHEN a.lifecycle_status = 'issued' THEN 'issued' ELSE 'stocked' END,
           a.assigned_user_id,
           CASE WHEN a.lifecycle_status = 'issued' THEN a.assigned_user END,
           'Initial lifecycle state',
           COALESCE(a.updated_at, a.created_at, NOW())
    FROM assets a
    WHERE NOT EXISTS (
      SELECT 1 FROM asset_assignment_history h WHERE h.asset_id = a.id
    );
  `);
  console.log('Staff, asset lifecycle, and software deployment migration complete.');
} finally {
  await pool.end();
}
