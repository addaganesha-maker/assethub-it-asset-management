import jwt from 'jsonwebtoken';

export function attachRealtime(io) {
  // Auth middleware
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    const agentKey = socket.handshake.auth?.agentKey;

    if (token) {
      try {
        socket.user = jwt.verify(token, process.env.JWT_SECRET);
        socket.isAdmin = true;
        return next();
      } catch {
        return next(new Error('invalid token'));
      }
    }
    if (agentKey) {
      socket.isAgent = true;
      return next();
    }
    next(new Error('unauthorized'));
  });

  io.on('connection', (socket) => {
    if (socket.isAdmin) {
      socket.join('admins');
    }
    if (socket.isAgent) {
      socket.join('agents');
    }

    socket.on('watch-asset', (assetId) => {
      if (socket.isAdmin) socket.join(`asset:${assetId}`);
    });

    socket.on('unwatch-asset', (assetId) => {
      socket.leave(`asset:${assetId}`);
    });

    socket.on('agent:metrics', (payload) => {
      if (!socket.isAgent) return;
      // Re-broadcast to any watching admins
      if (payload.asset_id) {
        io.to(`asset:${payload.asset_id}`).emit('live-update', payload);
      }
      io.to('admins').emit('live-update', payload);
    });
  });
}