import { randomUUID, createHash } from 'node:crypto';
import { mkdir, unlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import express, { Router } from 'express';
import { z } from 'zod';
import { pool, query } from '../config/db.js';
import { requireAgentKey, requireAuth, requirePermission } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/error.js';

const router = Router();
const packageDirectory = path.resolve(process.env.SOFTWARE_PACKAGE_DIR || path.join(process.cwd(), 'storage', 'software-packages'));
const productCodePattern = /^\{?[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\}?$/i;
const productCodeSchema = z.string().regex(productCodePattern, 'Enter a valid MSI ProductCode GUID.');

router.get('/packages', requireAuth, requirePermission('deployments', 'read'), asyncHandler(async (_req, res) => {
  const { rows } = await query(
    `SELECT p.id, p.name, p.version, p.original_name, p.package_type, p.product_code,
            p.install_args, p.sha256,
            p.size_bytes, p.created_at, u.full_name AS uploaded_by_name
     FROM software_deployment_packages p LEFT JOIN users u ON u.id = p.uploaded_by
     ORDER BY p.created_at DESC`
  );
  res.json({ data: rows });
}));

// MSI uses msiexec quiet mode; EXE packages use admin-supplied arguments as a safe argv list.
router.post(
  '/packages',
  requireAuth,
  requirePermission('deployments', 'write'),
  express.raw({ type: 'application/octet-stream', limit: '500mb' }),
  asyncHandler(async (req, res) => {
    const name = z.string().trim().min(1).max(200).safeParse(req.query.name);
    const version = z.string().trim().min(1).max(64).safeParse(req.query.version);
    const type = z.enum(['msi', 'exe']).safeParse(String(req.query.package_type || 'msi').toLowerCase());
    const originalName = path.basename(String(req.query.filename || ''));
    const extension = path.extname(originalName).toLowerCase();
    const code = productCodeSchema.safeParse(String(req.query.product_code || '').trim());
    let installArgs;
    try {
      installArgs = z.array(z.string().min(1).max(512).refine((arg) => !/[\x00-\x1f]/.test(arg))).max(50).safeParse(JSON.parse(String(req.query.install_args || '[]')));
    } catch {
      installArgs = { success: false };
    }
    if (!name.success || !version.success || !type.success || !installArgs.success) {
      return res.status(400).json({ error: 'Provide a name, version, package type, and up to 50 valid installer arguments.' });
    }
    if ((type.data === 'msi' && (!code.success || extension !== '.msi')) || (type.data === 'exe' && extension !== '.exe')) {
      return res.status(400).json({ error: type.data === 'msi'
        ? 'MSI packages need a valid ProductCode and .msi file.'
        : 'EXE packages need an .exe installer file.' });
    }
    if (type.data === 'exe' && installArgs.data.length === 0) {
      return res.status(400).json({ error: 'Enter the EXE installer’s silent arguments, one per line.' });
    }
    if (type.data === 'msi' && installArgs.data.length > 0) {
      return res.status(400).json({ error: 'MSI installers already run silently; do not provide EXE arguments.' });
    }
    if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
      return res.status(400).json({ error: 'Installer package body is empty.' });
    }
    const validMSI = req.body.length >= 8 && req.body.subarray(0, 8).equals(Buffer.from('d0cf11e0a1b11ae1', 'hex'));
    const peOffset = req.body.length >= 0x40 ? req.body.readUInt32LE(0x3c) : req.body.length;
    const validEXE = req.body.length >= 0x40
      && req.body.subarray(0, 2).equals(Buffer.from('4d5a', 'hex'))
      && peOffset >= 0x40 && peOffset <= req.body.length - 4
      && req.body.subarray(peOffset, peOffset + 4).equals(Buffer.from('50450000', 'hex'));
    if ((type.data === 'msi' && !validMSI) || (type.data === 'exe' && !validEXE)) {
      return res.status(400).json({ error: type.data === 'msi' ? 'Uploaded file does not have an MSI signature.' : 'Uploaded file does not have a valid Windows PE EXE signature.' });
    }
    const id = randomUUID();
    const storageName = `${id}${extension}`;
    const filePath = path.join(packageDirectory, storageName);
    const productCode = type.data === 'msi' ? `{${code.data.replace(/[{}]/g, '')}}` : null;
    await mkdir(packageDirectory, { recursive: true });
    await writeFile(filePath, req.body, { flag: 'wx' });
    try {
      const sha256 = createHash('sha256').update(req.body).digest('hex');
      await query(
        `INSERT INTO software_deployment_packages
           (id, name, version, original_name, storage_name, package_type, product_code, install_args, sha256, size_bytes, uploaded_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,$10,$11)`,
        [id, name.data, version.data, originalName, storageName, type.data, productCode,
          JSON.stringify(installArgs.data), sha256, req.body.length, req.user.id]
      );
      res.status(201).json({ id, name: name.data, version: version.data, package_type: type.data, sha256, size_bytes: req.body.length });
    } catch (error) {
      await unlink(filePath).catch(() => {});
      throw error;
    }
  })
);

router.get('/jobs', requireAuth, requirePermission('deployments', 'read'), asyncHandler(async (req, res) => {
  const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);
  const { rows } = await query(
    `SELECT j.id, j.asset_id, a.hostname, a.ip_address, j.package_id,
            COALESCE(j.software_name, p.name) AS package_name,
            COALESCE(j.software_version, p.version) AS version,
            j.action, j.status, j.exit_code,
            j.output, j.created_at, j.started_at, j.completed_at,
            u.full_name AS requested_by_name
     FROM software_deployment_jobs j
     JOIN assets a ON a.id = j.asset_id
     LEFT JOIN software_deployment_packages p ON p.id = j.package_id
     LEFT JOIN users u ON u.id = j.requested_by
     ORDER BY j.created_at DESC LIMIT $1`,
    [limit]
  );
  res.json({ data: rows });
}));

router.post('/jobs', requireAuth, requirePermission('deployments', 'write'), asyncHandler(async (req, res) => {
  const parsed = z.object({
    package_id: z.string().uuid().optional(),
    action: z.enum(['install', 'uninstall']),
    asset_ids: z.array(z.string().uuid()).min(1).max(500),
    software_name: z.string().trim().min(1).max(200).optional(),
    software_version: z.string().trim().max(64).optional(),
    product_code: z.string().regex(productCodePattern).optional(),
  }).superRefine((value, context) => {
    if (value.action === 'install' && !value.package_id) {
      context.addIssue({ code: 'custom', path: ['package_id'], message: 'Choose a software package to install.' });
    }
    if (value.action === 'uninstall' && !value.package_id && !value.product_code) {
      context.addIssue({ code: 'custom', path: ['product_code'], message: 'Choose an installed MSI application to uninstall.' });
    }
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid deployment request.' });
  const { package_id: packageId, action, asset_ids: assetIds } = parsed.data;
  if (packageId) {
    const { rows: packages } = await query('SELECT id, package_type FROM software_deployment_packages WHERE id = $1', [packageId]);
    if (!packages.length) return res.status(404).json({ error: 'Software package not found.' });
    if (action === 'uninstall' && packages[0].package_type !== 'msi') {
      return res.status(400).json({ error: 'Only MSI packages support the managed uninstall action.' });
    }
  }
  if (action === 'uninstall' && !packageId) {
    const productCode = `{${parsed.data.product_code.replace(/[{}]/g, '')}}`;
    const { rows: installed } = await query(
      `SELECT DISTINCT asset_id FROM installed_software
       WHERE asset_id = ANY($1::uuid[]) AND product_code = $2`,
      [Array.from(new Set(assetIds)), productCode]
    );
    if (installed.length !== new Set(assetIds).size) {
      return res.status(400).json({ error: 'The selected MSI application is not installed on every selected client.' });
    }
  }
  const { rows: assets } = await query(
    `SELECT id FROM assets
     WHERE id = ANY($1::uuid[]) AND status <> 'retired' AND os_name ILIKE '%windows%'`,
    [Array.from(new Set(assetIds))]
  );
  if (assets.length !== new Set(assetIds).size) return res.status(400).json({ error: 'Choose registered Windows clients only. One or more selected assets are missing, retired, or not running Windows.' });

  const jobs = [];
  for (const asset of assets) {
    const id = randomUUID();
    await query(
      `INSERT INTO software_deployment_jobs
         (id, package_id, asset_id, action, software_name, software_version, product_code, requested_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [id, packageId || null, asset.id, action, parsed.data.software_name || null,
        parsed.data.software_version || null,
        parsed.data.product_code ? `{${parsed.data.product_code.replace(/[{}]/g, '')}}` : null, req.user.id]
    );
    jobs.push(id);
  }
  res.status(201).json({ ok: true, job_ids: jobs, queued: jobs.length });
}));

router.get('/agent/jobs/next', requireAgentKey, asyncHandler(async (req, res) => {
  const assetId = z.string().uuid().safeParse(req.query.asset_id);
  if (!assetId.success) return res.status(400).json({ error: 'A valid asset_id is required.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE software_deployment_jobs
       SET status = 'queued', started_at = NULL
       WHERE asset_id = $1 AND status = 'running'
         AND started_at < NOW() - INTERVAL '2 hours'`,
      [assetId.data]
    );
    const { rows } = await client.query(
      `SELECT j.id, j.action, p.id AS package_id, p.package_type, p.install_args,
              COALESCE(j.software_name, p.name) AS name,
              COALESCE(j.software_version, p.version) AS version,
              COALESCE(j.product_code, p.product_code) AS product_code,
              p.sha256, p.original_name
       FROM software_deployment_jobs j
       LEFT JOIN software_deployment_packages p ON p.id = j.package_id
       WHERE j.asset_id = $1 AND j.status = 'queued'
       ORDER BY j.created_at ASC
       LIMIT 1 FOR UPDATE OF j SKIP LOCKED`,
      [assetId.data]
    );
    if (!rows.length) {
      await client.query('COMMIT');
      return res.json({ job: null });
    }
    const job = rows[0];
    await client.query(
      `UPDATE software_deployment_jobs SET status = 'running', started_at = NOW()
       WHERE id = $1`,
      [job.id]
    );
    await client.query('COMMIT');
    res.json({ job: { ...job, download_url: job.action === 'install' ? `/api/software-deploy/agent/jobs/${job.id}/package?asset_id=${assetId.data}` : '' } });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}));

router.get('/agent/jobs/:jobId/package', requireAgentKey, asyncHandler(async (req, res) => {
  const jobId = z.string().uuid().safeParse(req.params.jobId);
  const assetId = z.string().uuid().safeParse(req.query.asset_id);
  if (!jobId.success || !assetId.success) return res.status(400).json({ error: 'Invalid job or asset ID.' });
  const { rows } = await query(
    `SELECT p.storage_name, p.original_name
     FROM software_deployment_jobs j JOIN software_deployment_packages p ON p.id = j.package_id
     WHERE j.id = $1 AND j.asset_id = $2 AND j.status = 'running'`,
    [jobId.data, assetId.data]
  );
  if (!rows.length) return res.status(404).json({ error: 'Active job package not found.' });
  const filePath = path.join(packageDirectory, rows[0].storage_name);
  res.type('application/octet-stream');
  res.download(filePath, rows[0].original_name);
}));

router.post('/agent/jobs/:jobId/result', requireAgentKey, asyncHandler(async (req, res) => {
  const jobId = z.string().uuid().safeParse(req.params.jobId);
  const result = z.object({
    asset_id: z.string().uuid(),
    status: z.enum(['succeeded', 'failed']),
    exit_code: z.number().int().nullable().optional(),
    output: z.string().max(4000).optional(),
  }).safeParse(req.body);
  if (!jobId.success || !result.success) return res.status(400).json({ error: 'Invalid deployment result.' });
  const { rows } = await query(
    `UPDATE software_deployment_jobs
     SET status = $3, exit_code = $4, output = $5, completed_at = NOW()
     WHERE id = $1 AND asset_id = $2 AND status = 'running'
     RETURNING id`,
    [jobId.data, result.data.asset_id, result.data.status, result.data.exit_code ?? null, result.data.output || null]
  );
  if (!rows.length) return res.status(404).json({ error: 'Active deployment job not found.' });
  res.json({ ok: true });
}));

export default router;
