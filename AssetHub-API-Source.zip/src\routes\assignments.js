import { randomUUID } from 'node:crypto';
import { Router } from 'express';
import { z } from 'zod';
import { pool, query } from '../config/db.js';
import { requireAuth, requirePermission } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/error.js';
import {
  assignmentPolicyFileName,
  createAssignmentPolicyOutlookDraft,
  createAssignmentPolicyOutlookPayload,
  createAssignmentPolicyPdf,
  RETURN_CHECKLIST_DEFAULTS,
  createReturnPolicyPdf,
  sendAssignmentPolicyEmail,
  sendReturnPolicyEmail,
} from '../services/assignmentPolicy.js';

const router = Router();
const issueSchema = z.object({
  user_id: z.coerce.number().int().positive(),
  notes: z.string().trim().max(1000).optional().default(''),
  accessories: z.string().trim().max(500).optional().default(''),
  product_id: z.string().trim().max(128).optional().default(''),
  issue_condition: z.string().trim().max(160).optional().default(''),
  charger: z.enum(['Yes', 'No', '']).optional().default(''),
  mouse: z.enum(['Yes', 'No', '']).optional().default(''),
});
const returnChecklistRowSchema = z.object({
  item: z.string().trim().max(80),
  applicable: z.boolean(),
  returned: z.boolean(),
  remarks: z.string().trim().max(120),
});
const returnSchema = z.object({
  notes: z.string().trim().max(1000).optional().default(''),
  stock_section: z.enum(['main', 'spare', 'standby']).optional().default('main'),
  last_working_date: z.string().trim().refine((value) => value === '' || /^\d{4}-\d{2}-\d{2}$/.test(value), 'Last working date must be a valid date.').optional().default(''),
  checklist: z.array(returnChecklistRowSchema).length(RETURN_CHECKLIST_DEFAULTS.length).optional(),
});

router.use(requireAuth, requirePermission('assignments', 'read'));

router.get('/:assetId/history', asyncHandler(async (req, res) => {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(req.params.assetId)) {
    return res.status(400).json({ error: 'Invalid asset ID.' });
  }
  const { rows } = await query(
    `SELECT h.id, h.event_type, h.from_user_name,
            COALESCE(h.to_user_name, h.policy_snapshot->'employee'->>'full_name') AS to_user_name,
            h.occurred_at, h.notes,
            COALESCE(h.policy_snapshot->'employee'->>'employee_id', assigned.employee_id) AS employee_id,
            COALESCE(h.policy_snapshot->'employee'->>'division', assigned.division) AS division,
            COALESCE(h.policy_snapshot->'employee'->>'department', assigned.department) AS department
     FROM asset_assignment_history h
     LEFT JOIN staff_users assigned ON assigned.id = h.to_user_id
     WHERE h.asset_id = $1 AND h.event_type IN ('issued', 'returned')
     ORDER BY h.occurred_at DESC, h.id DESC`,
    [req.params.assetId]
  );
  res.json({ data: rows, total: rows.length });
}));

router.get('/history/:assignmentId/policy.pdf', asyncHandler(async (req, res) => {
  if (!/^\d+$/.test(req.params.assignmentId)) return res.status(400).json({ error: 'Invalid assignment ID.' });
  const { rows } = await query(
    `SELECT policy_snapshot FROM asset_assignment_history
     WHERE id = $1 AND event_type = 'issued'`,
    [req.params.assignmentId]
  );
  if (!rows.length || !rows[0].policy_snapshot) {
    return res.status(404).json({ error: 'No policy document is available for this assignment.' });
  }
  const pdf = await createAssignmentPolicyPdf(rows[0].policy_snapshot);
  res.set('Cache-Control', 'no-store');
  res.type('application/pdf').attachment(assignmentPolicyFileName(rows[0].policy_snapshot)).send(pdf);
}));

router.get('/history/:assignmentId/outlook.eml', asyncHandler(async (req, res) => {
  if (!/^\d+$/.test(req.params.assignmentId)) return res.status(400).json({ error: 'Invalid assignment ID.' });
  const { rows } = await query(
    `SELECT policy_snapshot FROM asset_assignment_history
     WHERE id = $1 AND event_type = 'issued'`,
    [req.params.assignmentId]
  );
  if (!rows.length || !rows[0].policy_snapshot) {
    return res.status(404).json({ error: 'No policy email draft is available for this assignment.' });
  }
  const snapshot = rows[0].policy_snapshot;
  const pdf = await createAssignmentPolicyPdf(snapshot);
  const eml = createAssignmentPolicyOutlookDraft(snapshot, pdf);
  const fileName = assignmentPolicyFileName(snapshot).replace(/\.pdf$/i, '.eml');
  res.set('Cache-Control', 'no-store');
  res.type('message/rfc822').attachment(fileName).send(eml);
}));

router.post('/history/:assignmentId/outlook-job', requirePermission('assignments', 'write'), asyncHandler(async (req, res) => {
  if (!/^\d+$/.test(req.params.assignmentId)) return res.status(400).json({ error: 'Invalid assignment ID.' });
  if ((process.env.OUTLOOK_WORKER_API_KEY || '').length < 32) {
    return res.status(503).json({ error: 'The Outlook Classic helper is not configured on the server.' });
  }
  const { rows } = await query(
    `SELECT policy_snapshot FROM asset_assignment_history
     WHERE id = $1 AND event_type = 'issued'`,
    [req.params.assignmentId]
  );
  if (!rows.length || !rows[0].policy_snapshot) {
    return res.status(404).json({ error: 'No policy email draft is available for this assignment.' });
  }
  const snapshot = rows[0].policy_snapshot;
  const pdf = await createAssignmentPolicyPdf(snapshot);
  const payload = createAssignmentPolicyOutlookPayload(snapshot, pdf);
  const jobId = randomUUID();
  await query(
    `INSERT INTO outlook_draft_jobs (id, assignment_id, requested_by, payload)
     VALUES ($1, $2, $3, $4::jsonb)`,
    [jobId, req.params.assignmentId, req.user.id, JSON.stringify(payload)]
  );
  res.status(202).json({ job_id: jobId, status: 'queued' });
}));

router.get('/outlook-jobs/:jobId', asyncHandler(async (req, res) => {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(req.params.jobId)) {
    return res.status(400).json({ error: 'Invalid Outlook draft job ID.' });
  }
  const { rows } = await query(
    `SELECT id, status, error_message, created_at, completed_at
     FROM outlook_draft_jobs WHERE id = $1 AND requested_by = $2`,
    [req.params.jobId, req.user.id]
  );
  if (!rows.length) return res.status(404).json({ error: 'Outlook draft job not found.' });
  res.json(rows[0]);
}));

router.post('/history/:assignmentId/email', requirePermission('assignments', 'write'), asyncHandler(async (req, res) => {
  if (!/^\d+$/.test(req.params.assignmentId)) return res.status(400).json({ error: 'Invalid assignment ID.' });
  const { rows } = await query(
    `SELECT policy_snapshot FROM asset_assignment_history
     WHERE id = $1 AND event_type = 'issued'`,
    [req.params.assignmentId]
  );
  if (!rows.length || !rows[0].policy_snapshot) {
    return res.status(404).json({ error: 'No policy document is available for this assignment.' });
  }
  const snapshot = rows[0].policy_snapshot;
  try {
    const pdf = await createAssignmentPolicyPdf(snapshot);
    await sendAssignmentPolicyEmail(snapshot, pdf);
    res.json({ email_sent: true });
  } catch (error) {
    console.error(`Could not resend assignment policy for history ${req.params.assignmentId}:`, error);
    const unavailable = error.code === 'EMAIL_NOT_CONFIGURED';
    res.status(unavailable ? 503 : 502).json({ error: unavailable
      ? error.message
      : 'The assignment policy email could not be sent. Check SMTP settings and try again.' });
  }
}));

router.get('/history/:returnId/return-policy.pdf', asyncHandler(async (req, res) => {
  if (!/^\d+$/.test(req.params.returnId)) return res.status(400).json({ error: 'Invalid return record ID.' });
  const { rows } = await query(
    `SELECT policy_snapshot FROM asset_assignment_history
     WHERE id = $1 AND event_type = 'returned'`,
    [req.params.returnId]
  );
  if (!rows.length || !rows[0].policy_snapshot) {
    return res.status(404).json({ error: 'No return policy is available for this asset return.' });
  }
  const pdf = await createReturnPolicyPdf(rows[0].policy_snapshot);
  res.set('Cache-Control', 'no-store');
  res.type('application/pdf').attachment(`Asset-Return-Policy-${Date.now()}.pdf`).send(pdf);
}));

router.post('/history/:returnId/return-email', requirePermission('assignments', 'write'), asyncHandler(async (req, res) => {
  if (!/^\d+$/.test(req.params.returnId)) return res.status(400).json({ error: 'Invalid return record ID.' });
  const { rows } = await query(
    `SELECT policy_snapshot FROM asset_assignment_history
     WHERE id = $1 AND event_type = 'returned'`,
    [req.params.returnId]
  );
  if (!rows.length || !rows[0].policy_snapshot) {
    return res.status(404).json({ error: 'No return policy is available for this asset return.' });
  }
  const snapshot = rows[0].policy_snapshot;
  try {
    const pdf = await createReturnPolicyPdf(snapshot);
    await sendReturnPolicyEmail(snapshot, pdf);
    res.json({ email_sent: true });
  } catch (error) {
    console.error(`Could not resend return policy for history ${req.params.returnId}:`, error);
    const unavailable = error.code === 'EMAIL_NOT_CONFIGURED';
    res.status(unavailable ? 503 : 502).json({ error: unavailable
      ? error.message
      : 'The asset return policy email could not be sent. Check SMTP settings and try again.' });
  }
}));

router.get('/stock', asyncHandler(async (req, res) => {
  const search = String(req.query.search || '').trim();
  const stockSection = String(req.query.stock_section || '').trim();
  const values = [];
  let filter = "a.lifecycle_status = 'stock' AND a.status <> 'retired'";
  let index = 1;

  if (stockSection && ['main', 'spare', 'standby'].includes(stockSection)) {
    values.push(stockSection);
    filter += ` AND a.stock_section = $${index++}`;
  }

  if (search) {
    values.push(`%${search}%`);
    filter += ` AND (a.hostname ILIKE $${index} OR a.asset_tag ILIKE $${index} OR a.serial_number ILIKE $${index} OR a.asset_type ILIKE $${index})`;
    index += 1;
  }

  const { rows } = await query(
    `SELECT a.id, COALESCE(NULLIF(a.asset_tag, ''), NULLIF(a.tags->>0, '')) AS asset_tag,
            COALESCE(a.tags, '[]'::jsonb) AS asset_tags,
            (SELECT COUNT(*)::int FROM asset_assignment_history h
             WHERE h.asset_id = a.id AND h.event_type = 'issued') AS usage_count,
            a.hostname, a.asset_type, a.manufacturer, a.model,
            a.serial_number, a.status AS device_status, a.lifecycle_status, a.stock_section,
            a.ip_address, a.last_seen, a.created_at
     FROM assets a WHERE ${filter}
     ORDER BY a.hostname ASC`,
    values
  );
  res.json({ data: rows, total: rows.length });
}));

router.get('/issued', asyncHandler(async (req, res) => {
  const search = String(req.query.search || '').trim();
  const values = [];
  let filter = "a.lifecycle_status = 'issued'";
  if (search) {
    values.push(`%${search}%`);
    filter += ` AND (a.hostname ILIKE $1 OR a.asset_tag ILIKE $1 OR a.serial_number ILIKE $1 OR a.assigned_user ILIKE $1 OR s.department ILIKE $1)`;
  }
  const { rows } = await query(
    `SELECT a.id, COALESCE(NULLIF(a.asset_tag, ''), NULLIF(a.tags->>0, '')) AS asset_tag,
            COALESCE(a.tags, '[]'::jsonb) AS asset_tags,
            (SELECT COUNT(*)::int FROM asset_assignment_history h
             WHERE h.asset_id = a.id AND h.event_type = 'issued') AS usage_count,
            a.hostname, a.asset_type, a.manufacturer, a.model,
            a.serial_number, a.status AS device_status, a.lifecycle_status,
            a.assigned_user, a.assigned_user_id, s.employee_id, s.email AS assigned_email,
            s.department AS assigned_department, a.last_seen,
            issue.id AS assignment_id, issue.occurred_at AS issued_at
     FROM assets a
     LEFT JOIN staff_users s ON s.id = a.assigned_user_id
     LEFT JOIN LATERAL (
       SELECT id, occurred_at FROM asset_assignment_history h
       WHERE h.asset_id = a.id AND h.event_type = 'issued'
       ORDER BY occurred_at DESC LIMIT 1
     ) issue ON TRUE
     WHERE ${filter}
     ORDER BY issue.occurred_at DESC NULLS LAST, a.hostname ASC`,
    values
  );
  res.json({ data: rows, total: rows.length });
}));

router.get('/history', asyncHandler(async (req, res) => {
  const search = String(req.query.search || '').trim();
  const values = [];
  const where = [];
  if (search) {
    values.push(`%${search}%`);
    where.push(`(a.hostname ILIKE $1 OR a.asset_tag ILIKE $1 OR h.from_user_name ILIKE $1 OR h.to_user_name ILIKE $1 OR h.notes ILIKE $1)`);
  }
  const { rows } = await query(
    `SELECT h.id, h.asset_id, h.event_type, h.from_user_name, h.to_user_name,
           h.notes, h.occurred_at,
           COALESCE(NULLIF(a.asset_tag, ''), NULLIF(a.tags->>0, '')) AS asset_tag,
           COALESCE(a.tags, '[]'::jsonb) AS asset_tags,
           a.hostname, a.asset_type,
            a.manufacturer, a.model,
            h.policy_snapshot->'employee'->>'email' AS assigned_email,
            actor.full_name AS performed_by_name
     FROM asset_assignment_history h
     JOIN assets a ON a.id = h.asset_id
     LEFT JOIN users actor ON actor.id = h.performed_by
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY h.occurred_at DESC
     LIMIT 1000`,
    values
  );
  res.json({ data: rows, total: rows.length });
}));

router.post('/:assetId/issue', requirePermission('assignments', 'write'), asyncHandler(async (req, res) => {
  const parsed = issueSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid assignment details.' });

  let snapshot;
  let assignmentId;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows: assets } = await client.query(
      `SELECT id, lifecycle_status, status, asset_tag, tags, hostname, asset_type, manufacturer,
              model, serial_number, cpu_model, os_name, os_version, os_build,
              architecture, ram_gb, disk_total_gb, storage_devices
       FROM assets WHERE id = $1 FOR UPDATE`,
      [req.params.assetId]
    );
    if (!assets.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Asset not found.' });
    }
    if (assets[0].lifecycle_status !== 'stock' || assets[0].status === 'retired') {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'Only stock assets can be issued.' });
    }

    const { rows: users } = await client.query(
      `SELECT id, employee_id, full_name, email, phone, department, division, job_title, location, status
       FROM staff_users WHERE id = $1 FOR KEY SHARE`,
      [parsed.data.user_id]
    );
    if (!users.length || users[0].status !== 'active') {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Choose an active user.' });
    }

    const user = users[0];
    const asset = assets[0];
    const { rows: previousAssignments } = await client.query(
      `SELECT to_user_name, policy_snapshot->'employee'->>'employee_id' AS employee_id
       FROM asset_assignment_history
       WHERE asset_id = $1 AND event_type = 'issued'
       ORDER BY occurred_at DESC, id DESC
       LIMIT 1`,
      [req.params.assetId]
    );
    const previousAssignment = previousAssignments[0] || null;
    const issueCondition = parsed.data.issue_condition === 'Replaced'
      ? `Replaced${previousAssignment?.to_user_name ? ` - ${previousAssignment.to_user_name}` : ''}`
      : parsed.data.issue_condition;
    snapshot = {
      employee: {
        employee_id: user.employee_id,
        full_name: user.full_name,
        email: user.email,
        phone: user.phone,
        department: user.department,
        division: user.division,
        job_title: user.job_title,
        location: user.location,
      },
      asset: {
        asset_tag: asset.asset_tag || asset.tags?.[0] || null,
        asset_tags: asset.tags || [],
        hostname: asset.hostname,
        asset_type: asset.asset_type,
        manufacturer: asset.manufacturer,
        model: asset.model,
        serial_number: asset.serial_number,
        product_id: parsed.data.product_id,
        cpu_model: asset.cpu_model,
        os_name: asset.os_name,
        os_version: asset.os_version,
        os_build: asset.os_build,
        architecture: asset.architecture,
        ram_gb: asset.ram_gb,
        disk_total_gb: asset.disk_total_gb,
        storage_devices: asset.storage_devices,
      },
      accessories: parsed.data.accessories,
      issue_condition: issueCondition,
      previous_assigned_user: parsed.data.issue_condition === 'Replaced'
        ? previousAssignment?.to_user_name || ''
        : '',
      charger: parsed.data.charger,
      mouse: parsed.data.mouse,
      notes: parsed.data.notes,
      issued_at: new Date().toISOString(),
    };
    await client.query(
      `UPDATE assets SET lifecycle_status = 'issued', assigned_user_id = $1,
         assigned_user = $2, updated_at = NOW() WHERE id = $3`,
      [user.id, user.full_name, req.params.assetId]
    );
    const { rows: history } = await client.query(
      `INSERT INTO asset_assignment_history
         (asset_id, event_type, to_user_id, to_user_name, performed_by, notes, policy_snapshot)
       VALUES ($1, 'issued', $2, $3, $4, $5, $6::jsonb)
       RETURNING id, occurred_at`,
      [req.params.assetId, user.id, user.full_name, req.user.id, parsed.data.notes || null, JSON.stringify(snapshot)]
    );
    assignmentId = history[0].id;
    snapshot.issued_at = history[0].occurred_at;
    await client.query('COMMIT');
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }

  let emailSent = false;
  let emailError = '';
  try {
    const pdf = await createAssignmentPolicyPdf(snapshot);
    await sendAssignmentPolicyEmail(snapshot, pdf);
    emailSent = true;
  } catch (error) {
    console.error(`Asset ${req.params.assetId} was issued but its policy email could not be sent:`, error);
    emailError = error.code === 'EMAIL_NOT_CONFIGURED'
      ? error.message
      : 'The asset was issued, but the policy email could not be sent. Check SMTP settings and resend it.';
  }
  res.json({
    ok: true,
    lifecycle_status: 'issued',
    assigned_user: snapshot.employee.full_name,
    policy_id: assignmentId,
    email_sent: emailSent,
    email_error: emailError || undefined,
  });
}));

router.post('/:assetId/return', requirePermission('assignments', 'write'), asyncHandler(async (req, res) => {
  const parsed = returnSchema.safeParse(req.body || {});
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid return details.' });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows: assets } = await client.query(
      `SELECT a.id, a.lifecycle_status, a.assigned_user_id, a.assigned_user, a.asset_tag, a.hostname,
              a.asset_type, a.manufacturer, a.model, a.serial_number, s.full_name AS current_user_name,
              s.employee_id, s.department, s.division, s.email
       FROM assets a LEFT JOIN staff_users s ON s.id = a.assigned_user_id
       WHERE a.id = $1 FOR UPDATE OF a`,
      [req.params.assetId]
    );
    if (!assets.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Asset not found.' });
    }
    const asset = assets[0];
    if (asset.lifecycle_status !== 'issued') {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'Only issued assets can be returned to stock.' });
    }

    const returnedAt = new Date().toISOString();
    const returnSnapshot = {
      employee: {
        full_name: asset.current_user_name || asset.assigned_user || 'Employee',
        employee_id: asset.employee_id || '',
        department: asset.department || '',
        division: asset.division || '',
        email: asset.email || '',
      },
      asset: {
        asset_tag: asset.asset_tag || '',
        hostname: asset.hostname || '',
        asset_type: asset.asset_type || '',
        manufacturer: asset.manufacturer || '',
        model: asset.model || '',
        serial_number: asset.serial_number || '',
      },
      return_section: parsed.data.stock_section,
      returned_at: returnedAt,
      last_working_date: parsed.data.last_working_date || returnedAt.slice(0, 10),
      checklist: (parsed.data.checklist || RETURN_CHECKLIST_DEFAULTS.map((item) => ({
        item,
        applicable: false,
        returned: false,
        remarks: '',
      }))).map((row) => ({ ...row })),
      notes: parsed.data.notes || '',
    };

    await client.query(
      `UPDATE assets SET lifecycle_status = 'stock', stock_section = $2, assigned_user_id = NULL,
         assigned_user = NULL, updated_at = NOW() WHERE id = $1`,
      [req.params.assetId, parsed.data.stock_section]
    );
    const { rows: history } = await client.query(
      `INSERT INTO asset_assignment_history
         (asset_id, event_type, from_user_id, from_user_name, performed_by, notes, policy_snapshot)
       VALUES ($1, 'returned', $2, $3, $4, $5, $6::jsonb)
       RETURNING id`,
      [req.params.assetId, asset.assigned_user_id, asset.current_user_name || asset.assigned_user, req.user.id, parsed.data.notes || null, JSON.stringify(returnSnapshot)]
    );
    await client.query('COMMIT');

    try {
      const pdf = await createReturnPolicyPdf(returnSnapshot);
      await sendReturnPolicyEmail(returnSnapshot, pdf);
      res.json({ ok: true, lifecycle_status: 'stock', return_policy_sent: true, return_policy_id: history[0]?.id || null });
    } catch (error) {
      console.error(`Asset ${req.params.assetId} was returned but its return policy email could not be sent:`, error);
      res.json({ ok: true, lifecycle_status: 'stock', return_policy_sent: false, return_policy_id: history[0]?.id || null, email_error: error.code === 'EMAIL_NOT_CONFIGURED' ? error.message : 'The return was recorded, but the return policy email could not be sent.' });
    }
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}));

export default router;
