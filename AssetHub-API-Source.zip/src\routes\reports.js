import { Router } from 'express';
import { query } from '../config/db.js';
import { requireAuth, requireAnyPermission, requirePermission } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/error.js';

const router = Router();

function toCsv(rows) {
  if (!rows.length) return '';
  const cols = Object.keys(rows[0]);
  const escape = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  return [
    cols.join(','),
    ...rows.map((r) => cols.map((c) => escape(r[c])).join(',')),
  ].join('\n');
}

router.get(
  '/assets.csv',
  requireAuth,
  requirePermission('reports', 'read'),
  asyncHandler(async (_req, res) => {
    const { rows } = await query(`
      SELECT asset_tag, hostname, asset_type, manufacturer, model, system_type,
             serial_number, system_uuid, purchase_date,
             CASE WHEN purchase_date IS NULL THEN NULL ELSE EXTRACT(YEAR FROM age(CURRENT_DATE, purchase_date))::int END AS age_years,
             CASE WHEN purchase_date IS NULL THEN NULL ELSE EXTRACT(MONTH FROM age(CURRENT_DATE, purchase_date))::int END AS age_months,
             CASE WHEN purchase_date IS NULL THEN NULL ELSE EXTRACT(DAY FROM age(CURRENT_DATE, purchase_date))::int END AS age_days,
             warranty_end_date,
             CASE WHEN warranty_end_date IS NULL THEN 'unknown' WHEN warranty_end_date >= CURRENT_DATE THEN 'in warranty' ELSE 'out of warranty' END AS warranty_status,
             warranty_checked_at, os_name, os_version, os_build, architecture,
             domain_joined, domain_name, workgroup_name, logged_in_domain, logged_in_user,
             user_session_seen_at, ip_address, mac_address, cpu_model, cpu_cores,
             ram_gb, disk_total_gb, disk_free_gb, gpu_model, bios_version,
             assigned_user, department, location, status, last_seen
      FROM assets ORDER BY hostname
    `);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="assets.csv"');
    res.send(toCsv(rows));
  })
);

router.get(
  '/software.csv',
  requireAuth,
  requireAnyPermission(['reports', 'read'], ['software', 'read']),
  asyncHandler(async (_req, res) => {
    const { rows } = await query(`
      SELECT s.hostname, i.software_name, i.version, i.publisher,
             i.install_date, i.is_authorized
      FROM installed_software i
      JOIN assets s ON s.id = i.asset_id
      ORDER BY s.hostname, i.software_name
    `);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="software.csv"');
    res.send(toCsv(rows));
  })
);

router.get(
  '/alerts.csv',
  requireAuth,
  requirePermission('reports', 'read'),
  asyncHandler(async (_req, res) => {
    const { rows } = await query(`
      SELECT a.created_at, s.hostname, a.rule_name, a.severity,
             a.message, a.metric_value, a.is_resolved
      FROM alerts a LEFT JOIN assets s ON s.id = a.asset_id
      ORDER BY a.created_at DESC
    `);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="alerts.csv"');
    res.send(toCsv(rows));
  })
);

export default router;
