import 'dotenv/config';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import express from 'express';
import http from 'http';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { Server as SocketServer } from 'socket.io';

import { pool } from './config/db.js';
import { attachRealtime } from './services/realtime.js';
import { startAlertEngine } from './services/alertEngine.js';
import { startMetricsFlusher } from './services/metricsBuffer.js';
import { startNetworkDiscoveryJob } from './services/networkDiscoveryJob.js';

import authRoutes from './routes/auth.js';
import assetRoutes from './routes/assets.js';
import metricRoutes from './routes/metrics.js';
import alertRoutes from './routes/alerts.js';
import reportRoutes from './routes/reports.js';
import userRoutes from './routes/users.js';
import assignmentRoutes from './routes/assignments.js';
import softwareDeploymentRoutes from './routes/softwareDeployments.js';
import networkDiscoveryRoutes from './routes/networkDiscovery.js';
import outlookWorkerRoutes from './routes/outlookWorker.js';
import accessControlRoutes from './routes/accessControl.js';
import siteRoutes from './routes/sites.js';
import { ensureSoftwareDeploymentTables } from './models/softwareDeployments.js';
import { ensureActiveDirectoryAuthSchema } from './models/activeDirectoryAuth.js';
import { ensureOutlookJobsSchema } from './models/outlookJobs.js';
import { ensureAgentInventorySchema } from './models/agentInventory.js';
import { ensureAssetTagsSchema } from './models/assetTags.js';
import { ensureDeletedAssetsSchema } from './models/deletedAssets.js';
import { ensureAssignmentPolicySchema } from './models/assignmentPolicies.js';
import { ensureStaffUsersSchema } from './models/staffUsers.js';
import { ensureAssetLifecycleSchema } from './models/assetLifecycle.js';
import { ensurePortalAccessSchema } from './services/portalAccess.js';
import { errorHandler } from './middleware/error.js';

const app = express();
const server = http.createServer(app);
const allowedOrigins = (process.env.CORS_ORIGINS || 'http://localhost:5173,http://127.0.0.1:5173')
  .split(',')
  .map((origin) => origin.trim())
  .filter(Boolean);
const corsOptions = {
  origin(origin, callback) {
    // Allow non-browser clients (agents and command-line tools), while limiting browser access.
    callback(null, !origin || allowedOrigins.includes(origin));
  },
  credentials: true,
  exposedHeaders: ['Content-Disposition'],
};

// ─── Security & middleware ────────────────────────────────
app.use(helmet());
app.use(cors(corsOptions));
app.use(express.json({ limit: '5mb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, max: 600 }));

// ─── Routes ───────────────────────────────────────────────
app.get('/health', (_req, res) =>
  res.json({ ok: true, ts: new Date().toISOString() })
);
app.use('/api/auth', authRoutes);
app.use('/api/assets', assetRoutes);
app.use('/api/metrics', metricRoutes);
app.use('/api/alerts', alertRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/users', userRoutes);
app.use('/api/assignments', assignmentRoutes);
app.use('/api/software-deploy', softwareDeploymentRoutes);
app.use('/api/network-discovery', networkDiscoveryRoutes);
app.use('/api/outlook-worker', outlookWorkerRoutes);
app.use('/api/access-control', accessControlRoutes);
app.use('/api/sites', siteRoutes);

app.use(errorHandler);

// ─── WebSocket ────────────────────────────────────────────
const io = new SocketServer(server, {
  cors: corsOptions,
  path: '/socket.io',
});
attachRealtime(io);
app.set('io', io);

// ─── Background workers ───────────────────────────────────
startMetricsFlusher();
startAlertEngine(io);

// ─── Bootstrap admin user ─────────────────────────────────
async function ensureAdmin() {
  const email = process.env.ADMIN_EMAIL || 'admin@assethub.local';
  const password = process.env.ADMIN_PASSWORD || (process.env.NODE_ENV === 'production' ? '' : 'admin123');
  if (!password) throw new Error('ADMIN_PASSWORD must be set in production');
  const { rows } = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
  if (rows.length) return;
  const bcrypt = await import('bcryptjs');
  const hash = await bcrypt.default.hash(password, 10);
  await pool.query(
    `INSERT INTO users (email, password_hash, role, full_name)
     VALUES ($1, $2, 'admin', 'System Admin')`,
    [email, hash]
  );
  console.log(`✓ Seeded admin user: ${email}`);
}

async function ensureAgentKey() {
  const key = process.env.AGENT_API_KEY;
  if (!key) throw new Error('AGENT_API_KEY must be set before agent check-ins can be enabled');
  const { rows } = await pool.query(
    'SELECT id, label, key_hash FROM agent_keys WHERE is_active = TRUE'
  );
  const bcrypt = await import('bcryptjs');
  for (const row of rows) {
    if (await bcrypt.default.compare(key, row.key_hash)) return;
    if (row.label === 'AssetHub configured agent key') {
      const hash = await bcrypt.default.hash(key, 10);
      await pool.query('UPDATE agent_keys SET key_hash = $1 WHERE id = $2', [hash, row.id]);
      console.log('✓ Rotated the configured AssetHub agent key');
      return;
    }
  }

  const hash = await bcrypt.default.hash(key, 10);
  await pool.query(
    `INSERT INTO agent_keys (key_hash, label, is_active)
     VALUES ($1, 'AssetHub configured agent key', TRUE)`,
    [hash]
  );
  console.log('✓ Registered the configured AssetHub agent key');
}

const PORT = process.env.PORT || 4000;
try {
  // Create the base schema on a fresh managed database before running incremental setup.
  const schemaUrl = new URL('./models/schema.sql', import.meta.url);
  await pool.query(await readFile(fileURLToPath(schemaUrl), 'utf8'));
  await ensureActiveDirectoryAuthSchema();
  await ensureAgentInventorySchema();
  await ensureAssetTagsSchema();
  await ensureStaffUsersSchema();
  await ensureAssetLifecycleSchema();
  await ensureSoftwareDeploymentTables();
  await ensureDeletedAssetsSchema();
  await ensureAssignmentPolicySchema();
  await ensureOutlookJobsSchema();
  await ensurePortalAccessSchema((text) => pool.query(text));
} catch (error) {
  console.error('Application schema setup failed:', error.message);
  process.exit(1);
}

server.listen(PORT, async () => {
  try {
    await ensureAdmin();
    await ensureAgentKey();
  } catch (e) {
    console.error('Bootstrap seed failed:', e.message);
  }
  startNetworkDiscoveryJob();
  console.log(`🟢 AssetHub API listening on :${PORT}`);
});
