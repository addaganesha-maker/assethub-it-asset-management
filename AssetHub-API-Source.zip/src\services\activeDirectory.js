import { readFile } from 'node:fs/promises';
import { Client, Filter, InvalidCredentialsError } from 'ldapts';

const adConfig = () => ({
  url: process.env.AD_LDAP_URL?.trim(),
  baseDn: process.env.AD_BASE_DN?.trim(),
  bindDn: process.env.AD_BIND_DN?.trim(),
  bindPassword: process.env.AD_BIND_PASSWORD,
});

export function isActiveDirectoryConfigured() {
  const { url, baseDn, bindDn, bindPassword } = adConfig();
  return Boolean(url && baseDn && bindDn && bindPassword);
}

function createClient(url, ca) {
  return new Client({
    url,
    timeout: 5000,
    connectTimeout: 5000,
    tlsOptions: ca ? { minVersion: 'TLSv1.2', ca: [ca] } : { minVersion: 'TLSv1.2' },
  });
}

function attribute(entry, name) {
  const value = entry[name];
  if (Array.isArray(value)) return value[0] == null ? '' : String(value[0]);
  return value == null ? '' : String(value);
}

async function close(client) {
  await client.unbind().catch(() => {});
}

export async function authenticateActiveDirectory(username, password) {
  const { url, baseDn, bindDn, bindPassword } = adConfig();
  if (!isActiveDirectoryConfigured()) return null;
  if (new URL(url).protocol !== 'ldaps:') {
    throw new Error('Active Directory requires LDAPS. Set AD_LDAP_URL to an ldaps:// URL.');
  }

  const ca = process.env.AD_CA_CERT_PATH ? await readFile(process.env.AD_CA_CERT_PATH) : null;
  const serviceClient = createClient(url, ca);
  let user;
  try {
    await serviceClient.bind(bindDn, bindPassword);
    const escapedUsername = Filter.escape(username.trim());
    const { searchEntries } = await serviceClient.search(baseDn, {
      scope: 'sub',
      sizeLimit: 2,
      timeLimit: 5,
      filter: `(&(objectCategory=person)(objectClass=user)(|(sAMAccountName=${escapedUsername})(userPrincipalName=${escapedUsername})(mail=${escapedUsername})))`,
      attributes: ['distinguishedName', 'employeeID', 'mail', 'userPrincipalName', 'displayName', 'sAMAccountName', 'userAccountControl'],
    });
    if (searchEntries.length !== 1) return null;
    user = searchEntries[0];
  } finally {
    await close(serviceClient);
  }

  const accountControl = Number(attribute(user, 'userAccountControl')) || 0;
  if (accountControl & 2) return null;

  const userDn = attribute(user, 'dn') || attribute(user, 'distinguishedName');
  if (!userDn || !attribute(user, 'employeeID')) return null;

  const userClient = createClient(url, ca);
  try {
    await userClient.bind(userDn, password);
  } catch (error) {
    if (error instanceof InvalidCredentialsError || error?.code === 49) return null;
    throw error;
  } finally {
    await close(userClient);
  }

  const email = attribute(user, 'mail') || attribute(user, 'userPrincipalName');
  if (!email || !email.includes('@')) return null;
  return {
    employeeId: attribute(user, 'employeeID').trim(),
    email: email.trim().toLowerCase(),
    fullName: attribute(user, 'displayName') || attribute(user, 'sAMAccountName') || username.trim(),
  };
}

