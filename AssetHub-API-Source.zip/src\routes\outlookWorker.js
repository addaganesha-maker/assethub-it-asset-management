import { timingSafeEqual } from 'node:crypto';
import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../config/db.js';
import { asyncHandler } from '../middleware/error.js';

const router = Router();
const resultSchema = z.object({
  status: z.enum(['opened', 'failed']),
  error: z.string().trim().max(500).optional().default(''),
});

function requireOutlookWorker(req, res, next) {
  const expected = process.env.OUTLOOK_WORKER_API_KEY || '';
  const supplied = req.headers['x-outlook-worker-key'];
  const actual = typeof supplied === 'string' ? supplied : '';
  const expectedBuffer = Buffer.from(expected);
  const actualBuffer = Buffer.from(actual);
  if (expectedBuffer.length < 32 || expectedBuffer.length !== actualBuffer.length
      || !timingSafeEqual(expectedBuffer, actualBuffer)) {
    return res.status(401).json({ error: 'Invalid Outlook worker credentials.' });
  }
  return next();
}

router.use(requireOutlookWorker);

router.get('/jobs/next', asyncHandler(async (_req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(`
      UPDATE outlook_draft_jobs
      SET status = 'failed', payload = NULL,
          error_message = CASE
            WHEN created_at <= NOW() - INTERVAL '1 day'
              THEN 'The Outlook helper did not open this draft within 24 hours.'
            ELSE 'The Outlook helper could not process this draft after multiple attempts.'
          END,
          lease_expires_at = NULL, completed_at = NOW()
      WHERE (status IN ('queued', 'processing') AND created_at <= NOW() - INTERVAL '1 day')
         OR (status = 'processing' AND attempts >= 3 AND lease_expires_at < NOW())
    `);
    const { rows } = await client.query(
      `SELECT id, payload FROM outlook_draft_jobs
       WHERE created_at > NOW() - INTERVAL '1 day'
         AND attempts < 3
         AND (status = 'queued' OR (status = 'processing' AND lease_expires_at < NOW()))
       ORDER BY created_at, id
       LIMIT 1 FOR UPDATE SKIP LOCKED`
    );
    if (!rows.length) {
      await client.query('COMMIT');
      return res.json({ job: null });
    }
    await client.query(
      `UPDATE outlook_draft_jobs
       SET status = 'processing', attempts = attempts + 1,
           lease_expires_at = NOW() + INTERVAL '2 minutes'
       WHERE id = $1`,
      [rows[0].id]
    );
    await client.query('COMMIT');
    return res.json({ job: { id: rows[0].id, ...rows[0].payload } });
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}));

router.post('/jobs/:id/result', asyncHandler(async (req, res) => {
  const parsed = resultSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid Outlook worker result.' });
  const { rows } = await pool.query(
    `UPDATE outlook_draft_jobs
     SET status = $1, payload = NULL, error_message = $2,
         lease_expires_at = NULL, completed_at = NOW()
     WHERE id = $3 AND status = 'processing'
     RETURNING id`,
    [parsed.data.status, parsed.data.status === 'failed' ? parsed.data.error || 'Outlook could not open the draft.' : null, req.params.id]
  );
  if (!rows.length) return res.status(404).json({ error: 'Outlook draft job was not found or is no longer active.' });
  return res.json({ ok: true });
}));

export default router;
