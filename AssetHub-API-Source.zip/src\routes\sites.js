import { Router } from 'express';
import { isIP } from 'node:net';
import { pool, query } from '../config/db.js';
import { requireAuth, requirePermission } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/error.js';

const router = Router();

function isUsableIPv4(value) {
  const parts = value.split('.').map(Number);
  const [first, second] = parts;
  return isIP(value) === 4
    && first !== 0 && first !== 127 && first < 224
    && !(first === 169 && second === 254)
    && value !== '255.255.255.255';
}

function parseSite(value) {
  const name = typeof value?.name === 'string' ? value.name.trim() : '';
  const subnets = Array.isArray(value?.subnets)
    ? [...new Set(value.subnets.map((item) => typeof item === 'string' ? item.trim() : '').filter(Boolean))]
    : [];
  if (!name || name.length > 100) return { error: 'Site name is required and must be no more than 100 characters.' };
  if (!subnets.length || subnets.length > 100) return { error: 'Add between 1 and 100 IP addresses or CIDR subnet ranges.' };
  let configuredTargets = 0;
  for (const subnet of subnets) {
    const [address, prefixText, extra] = subnet.split('/');
    const version = isIP(address);
    const prefix = prefixText === undefined ? (version === 4 ? 32 : 128) : Number(prefixText);
    if (version !== 4 || !isUsableIPv4(address) || extra !== undefined || !Number.isInteger(prefix) || prefix < 20 || prefix > 32) {
      return { error: `Use a valid IPv4 address or CIDR range from /20 through /32: ${subnet}` };
    }
    const octets = address.split('.').map(Number);
    const value = octets.reduce((result, octet) => result * 256 + octet, 0);
    const blockSize = 2 ** (32 - prefix);
    const network = Math.floor(value / blockSize) * blockSize;
    const firstHost = prefix < 31 ? network + 1 : network;
    const lastHost = prefix < 31 ? network + blockSize - 2 : network + blockSize - 1;
    const ipText = (ip) => [Math.floor(ip / 16777216), Math.floor(ip / 65536) % 256,
      Math.floor(ip / 256) % 256, ip % 256].join('.');
    if (!isUsableIPv4(ipText(firstHost)) || !isUsableIPv4(ipText(lastHost))) {
      return { error: `The range includes reserved IPv4 addresses that cannot be scanned: ${subnet}` };
    }
    configuredTargets += lastHost - firstHost + 1;
    if (configuredTargets > 4096) {
      return { error: 'A site can contain no more than 4,096 IP targets across all ranges.' };
    }
  }
  return { data: { name, subnets } };
}

async function replaceSiteSubnets(client, siteId, subnets) {
  await client.query('DELETE FROM site_subnets WHERE site_id = $1', [siteId]);
  for (const subnet of subnets) {
    await client.query('INSERT INTO site_subnets (site_id, subnet) VALUES ($1, $2::cidr)', [siteId, subnet]);
  }
}

router.get('/', requireAuth, requirePermission('sites', 'read'), asyncHandler(async (_req, res) => {
  const { rows } = await query(`
    SELECT s.id, s.name, s.created_at, s.updated_at,
      COALESCE(jsonb_agg(ss.subnet::text ORDER BY ss.subnet::text)
        FILTER (WHERE ss.id IS NOT NULL), '[]'::jsonb) AS subnets
    FROM sites s LEFT JOIN site_subnets ss ON ss.site_id = s.id
    GROUP BY s.id ORDER BY LOWER(s.name), s.name
  `);
  res.json({ data: rows });
}));

router.post('/', requireAuth, requirePermission('sites', 'write'), asyncHandler(async (req, res) => {
  const parsed = parseSite(req.body);
  if (parsed.error) return res.status(400).json({ error: parsed.error });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(
      'INSERT INTO sites (name) VALUES ($1) RETURNING id, name, created_at, updated_at',
      [parsed.data.name]
    );
    await replaceSiteSubnets(client, rows[0].id, parsed.data.subnets);
    await client.query('COMMIT');
    res.status(201).json({ ...rows[0], subnets: parsed.data.subnets });
  } catch (error) {
    await client.query('ROLLBACK');
    if (error.code === '23505') return res.status(409).json({ error: 'A site with this name already exists.' });
    if (error.code === '22P02') return res.status(400).json({ error: 'One of the subnet ranges is not valid.' });
    throw error;
  } finally {
    client.release();
  }
}));

router.patch('/:id', requireAuth, requirePermission('sites', 'write'), asyncHandler(async (req, res) => {
  if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid site ID.' });
  const parsed = parseSite(req.body);
  if (parsed.error) return res.status(400).json({ error: parsed.error });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(
      'UPDATE sites SET name = $1, updated_at = NOW() WHERE id = $2 RETURNING id, name, created_at, updated_at',
      [parsed.data.name, req.params.id]
    );
    if (!rows.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Site not found.' });
    }
    await replaceSiteSubnets(client, req.params.id, parsed.data.subnets);
    await client.query('COMMIT');
    res.json({ ...rows[0], subnets: parsed.data.subnets });
  } catch (error) {
    await client.query('ROLLBACK');
    if (error.code === '23505') return res.status(409).json({ error: 'A site with this name already exists.' });
    if (error.code === '22P02') return res.status(400).json({ error: 'One of the subnet ranges is not valid.' });
    throw error;
  } finally {
    client.release();
  }
}));

router.delete('/:id', requireAuth, requirePermission('sites', 'delete'), asyncHandler(async (req, res) => {
  if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid site ID.' });
  const { rowCount } = await query('DELETE FROM sites WHERE id = $1', [req.params.id]);
  if (!rowCount) return res.status(404).json({ error: 'Site not found.' });
  res.json({ ok: true });
}));

export default router;
