import { chromium } from 'playwright';

function getLookupSite(asset) {
  const manufacturer = asset.manufacturer || '';
  if (/dell/i.test(manufacturer)) return { url: 'https://www.dell.com/support/contractservices/en-in' };
  if (/lenovo/i.test(manufacturer)) {
    return { url: /server|storage|network/i.test(asset.asset_type || '')
      ? 'https://datacentersupport.lenovo.com/in/en/warranty-lookup'
      : 'https://pcsupport.lenovo.com/in/en/warranty-lookup#/' };
  }
  if (/hp|hewlett/i.test(manufacturer)) return { url: 'https://support.hp.com/in-en/check-warranty' };
  return null;
}

function dateFrom(text) {
  const value = text.trim();
  const iso = value.match(/\b(20\d{2})[-/](0?[1-9]|1[0-2])[-/](0?[1-9]|[12]\d|3[01])\b/);
  if (iso) return `${iso[1]}-${iso[2].padStart(2, '0')}-${iso[3].padStart(2, '0')}`;
  const numeric = value.match(/\b(0?[1-9]|[12]\d|3[01])[-/](0?[1-9]|1[0-2])[-/](20\d{2})\b/);
  if (numeric) return `${numeric[3]}-${numeric[2].padStart(2, '0')}-${numeric[1].padStart(2, '0')}`;
  const named = value.match(/\b(0?[1-9]|[12]\d|3[01])\s+([A-Za-z]{3,9})\s+(20\d{2})\b/);
  if (named) {
    const month = new Date(`${named[2]} 1, 2000`).getMonth() + 1;
    if (Number.isFinite(month)) return `${named[3]}-${String(month).padStart(2, '0')}-${named[1].padStart(2, '0')}`;
  }
  const namedUs = value.match(/\b([A-Za-z]{3,9})\s+(0?[1-9]|[12]\d|3[01]),?\s+(20\d{2})\b/);
  if (namedUs) {
    const month = new Date(`${namedUs[1]} 1, 2000`).getMonth() + 1;
    if (Number.isFinite(month)) return `${namedUs[3]}-${String(month).padStart(2, '0')}-${namedUs[2].padStart(2, '0')}`;
  }
  return null;
}

function warrantyEndFrom(text) {
  const label = /(?:(?:warranty|coverage|service|support)\s*(?:end|expiration|expires|expiry|through|until|valid\s+(?:to|until)|to)\s*(?:date)?|(?:end|expires|expiration)\s+of\s+(?:limited\s+)?(?:warranty|coverage))\s*[:\-]?/ig;
  for (const match of text.matchAll(label)) {
    const date = dateFrom(text.slice(match.index + match[0].length, match.index + match[0].length + 100));
    if (date) return date;
  }
  return null;
}

export async function fetchWarrantyEndDate(asset) {
  const site = getLookupSite(asset);
  if (!site) throw new Error(`Automatic website lookup is not configured for ${asset.manufacturer || 'this manufacturer'}.`);
  if (!asset.serial_number?.trim()) throw new Error('This asset has no serial number to look up.');

  let browser;
  try {
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
    const page = await browser.newPage({ locale: 'en-IN', timezoneId: 'Asia/Kolkata' });
    await page.goto(site.url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(1500);
    const pageTitle = await page.title();
    const initialText = (await page.locator('body').innerText().catch(() => '')).slice(0, 1500);
    if (/access denied|unusual traffic|verify you are human|captcha/i.test(`${pageTitle} ${initialText}`)) {
      throw new Error('The manufacturer is blocking automated warranty checks from this server. Open the support page manually, check this serial number, then enter the warranty end date here.');
    }

    let formFrame = page.mainFrame();
    let input = null;
    for (const frame of page.frames()) {
      const target = await frame.locator('input').evaluateAll((inputs) => {
        const score = (input) => `${input.getAttribute('aria-label') || ''} ${input.getAttribute('placeholder') || ''} ${input.name || ''} ${input.id || ''} ${[...(input.labels || [])].map((label) => label.innerText).join(' ')} ${input.parentElement?.innerText || ''}`;
        const serial = inputs.find((candidate) => /serial|service\s*tag|product\s*number|machine\s*type/i.test(score(candidate)) && !candidate.disabled && candidate.type !== 'hidden');
        const candidate = serial || inputs.find((item) => !item.disabled && item.type !== 'hidden' && ['text', 'search', ''].includes(item.type));
        if (!candidate) return null;
        return candidate.id ? `#${CSS.escape(candidate.id)}` : candidate.name ? `input[name="${CSS.escape(candidate.name)}"]` : 'input';
      }).catch(() => null);
      if (target) {
        formFrame = frame;
        input = frame.locator(target).first();
        break;
      }
    }
    if (!input) {
      for (const frame of page.frames()) {
        const textbox = frame.getByRole('textbox').first();
        if (await textbox.count().catch(() => 0)) {
          formFrame = frame;
          input = textbox;
          break;
        }
      }
    }
    if (!input) throw new Error('Could not find an editable product or serial field on the manufacturer website.');
    await input.fill(asset.serial_number.trim());

    const submit = formFrame.getByRole('button', { name: /check|submit|search|continue|go|find|identify/i }).first();
    if (await submit.count()) await submit.click();
    else await input.press('Enter');
    await page.waitForTimeout(3500);
    const visibleText = (await Promise.all(page.frames().map((frame) => frame.locator('body').innerText({ timeout: 3000 }).catch(() => '')))).join('\n');
    const warrantyEndDate = warrantyEndFrom(visibleText);
    if (!warrantyEndDate) {
      throw new Error('The manufacturer page did not show a readable warranty end date. Check whether it requires a region, sign-in, or CAPTCHA.');
    }
    return { warrantyEndDate, sourceUrl: page.url() };
  } catch (error) {
    if (error.message?.includes('warranty end date') || error.message?.includes('manufacturer website') || error.message?.includes('editable product') || error.message?.includes('not configured') || error.message?.includes('no serial number')) throw error;
    throw new Error(`Warranty page lookup failed: ${error.message}`);
  } finally {
    await browser?.close();
  }
}
