import { query } from '../config/db.js';

export async function ensureStaffUsersSchema() {
  await query(`
    ALTER TABLE staff_users
      ADD COLUMN IF NOT EXISTS division VARCHAR(128),
      ADD COLUMN IF NOT EXISTS resignation_date DATE;
    ALTER TABLE staff_users DROP CONSTRAINT IF EXISTS staff_users_status_check;
    ALTER TABLE staff_users ADD CONSTRAINT staff_users_status_check
      CHECK (status IN ('active', 'inactive', 'on_leave', 'resigned'));
  `);
}
