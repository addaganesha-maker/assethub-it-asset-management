import { query } from '../config/db.js';

// Track "since when" an asset has been above a rule threshold
const sustained = new Map(); // key -> firstTimestampMs

let cachedRules = [];
let ioRef = null;

async function loadRules() {
  try {
    const { rows } = await query(
      'SELECT * FROM alert_rules WHERE is_active = TRUE'
    );
    cachedRules = rows;
  } catch (e) {
    console.error('loadRules error', e.message);
  }
}

function compare(val, op, threshold) {
  switch (op) {
    case '>':  return val >  threshold;
    case '<':  return val <  threshold;
    case '>=': return val >= threshold;
    case '<=': return val <= threshold;
    default:   return false;
  }
}

export async function evaluate(m) {
  const now = Date.now();

  for (const rule of cachedRules) {
    const val = Number(m[rule.metric]);
    if (!isFinite(val)) continue;

    const key = `${m.asset_id}:${rule.id}`;
    const breached = compare(val, rule.operator, Number(rule.threshold));

    if (breached) {
      const since = sustained.get(key);
      if (!since) {
        sustained.set(key, now);
      }
      const sustainedSec = (now - (sustained.get(key) || now)) / 1000;
      if (sustainedSec >= (rule.duration_sec || 0)) {
        // Avoid duplicates: don't create alert if one exists in last 15 min
        const { rows: existing } = await query(
          `SELECT id FROM alerts
           WHERE asset_id = $1 AND rule_name = $2
             AND is_resolved = FALSE
             AND created_at > NOW() - INTERVAL '15 minutes'
           LIMIT 1`,
          [m.asset_id, rule.name]
        );
        if (!existing.length) {
          const { rows } = await query(
            `INSERT INTO alerts (asset_id, rule_name, severity, message, metric_value)
             VALUES ($1, $2, $3, $4, $5) RETURNING *`,
            [
              m.asset_id,
              rule.name,
              rule.severity,
              `${rule.metric} = ${val} (threshold ${rule.operator}${rule.threshold})`,
              val,
            ]
          );
          if (ioRef) {
            ioRef.to('admins').emit('alert', rows[0]);
          }
        }
      }
    } else {
      sustained.delete(key);
    }
  }
}

export function startAlertEngine(io) {
  ioRef = io;
  loadRules();
  setInterval(loadRules, 60_000);
}