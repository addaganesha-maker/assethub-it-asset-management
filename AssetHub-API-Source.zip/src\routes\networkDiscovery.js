import { Router } from 'express';
import { isIP } from 'node:net';
import { query } from '../config/db.js';
import { requireAgentKey, requireAuth, requirePermission } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/error.js';
import { getNetworkDiscoveryStatus, runNetworkDiscoveryScan } from '../services/networkDiscoveryJob.js';

const router = Router();
const macPattern = /^(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}$/i;

function ipv4Number(value) {
  if (isIP(value) !== 4) return null;
  return value.split('.').reduce((result, part) => ((result << 8) | Number(part)) >>> 0, 0);
}

function validIPv4Subnet(ip, cidr) {
  if (typeof cidr !== 'string') return false;
  const [network, prefixText] = cidr.split('/');
  const prefix = Number(prefixText);
  const address = ipv4Number(ip);
  const networkAddress = ipv4Number(network);
  if (address === null || networkAddress === null || !Number.isInteger(prefix) || prefix < 16 || prefix > 32) return false;
  const mask = (0xffffffff << (32 - prefix)) >>> 0;
  return (address & mask) === (networkAddress & mask);
}

router.get('/status', requireAuth, requirePermission('network_discovery', 'read'), (_req, res) => {
  res.json(getNetworkDiscoveryStatus());
});

router.post('/scan', requireAuth, requirePermission('network_discovery', 'write'), (_req, res) => {
  void runNetworkDiscoveryScan();
  res.status(202).json({ ok: true, message: 'Network discovery scan started.' });
});

router.get('/', requireAuth, requirePermission('network_discovery', 'read'), asyncHandler(async (_req, res) => {
  const { rows } = await query(`
    SELECT DISTINCT ON (d.ip_address::text)
      d.id, d.ip_address::text AS ip_address, d.mac_address, d.hostname,
      d.subnet::text AS subnet, d.first_seen, d.last_seen,
      COALESCE(observer.hostname, 'Network scan host') AS discovered_by,
      registered.id AS registered_asset_id,
      registered.hostname AS registered_hostname,
      registered.agent_version,
      registered.agent_installed_at,
      matched_site.name AS site_name
    FROM network_discoveries d
    LEFT JOIN assets observer ON observer.id = d.observer_asset_id
    LEFT JOIN assets registered ON
      (d.mac_address IS NOT NULL AND LOWER(registered.mac_address) = LOWER(d.mac_address))
      OR registered.ip_address = d.ip_address::text
    LEFT JOIN LATERAL (
      SELECT s.name
      FROM site_subnets ss JOIN sites s ON s.id = ss.site_id
      WHERE d.ip_address <<= ss.subnet
      ORDER BY masklen(ss.subnet) DESC
      LIMIT 1
    ) matched_site ON TRUE
    WHERE d.last_seen > NOW() - INTERVAL '14 days'
      AND EXISTS (SELECT 1 FROM site_subnets ss WHERE d.ip_address <<= ss.subnet)
    ORDER BY d.ip_address::text, d.last_seen DESC
  `);
  res.json({ data: rows });
}));

async function storeDiscoveries(devices, observerId) {
  let saved = 0;
  for (const device of devices) {
    const ip = typeof device?.ip_address === 'string' ? device.ip_address : '';
    const subnet = typeof device?.subnet === 'string' ? device.subnet : '';
    if (!validIPv4Subnet(ip, subnet)) continue;
    const mac = typeof device.mac_address === 'string' && macPattern.test(device.mac_address) ? device.mac_address : null;
    const hostname = typeof device.hostname === 'string' ? device.hostname.trim().slice(0, 255) : '';
    if (observerId) {
      const result = await query(`
        INSERT INTO network_discoveries (observer_asset_id, subnet, ip_address, mac_address, hostname)
        SELECT $1, $2::cidr, $3::inet, $4, $5
        WHERE EXISTS (SELECT 1 FROM site_subnets ss WHERE $3::inet <<= ss.subnet)
        ON CONFLICT (observer_asset_id, ip_address) DO UPDATE SET
          subnet = EXCLUDED.subnet,
          mac_address = COALESCE(EXCLUDED.mac_address, network_discoveries.mac_address),
          hostname = COALESCE(NULLIF(EXCLUDED.hostname, ''), network_discoveries.hostname),
          last_seen = NOW()
      `, [observerId, subnet, ip, mac, hostname || null]);
      saved += result.rowCount;
    } else {
      const result = await query(`
        INSERT INTO network_discoveries (observer_asset_id, subnet, ip_address, mac_address, hostname)
        SELECT NULL, $1::cidr, $2::inet, $3, $4
        WHERE EXISTS (SELECT 1 FROM site_subnets ss WHERE $2::inet <<= ss.subnet)
        ON CONFLICT (ip_address) WHERE observer_asset_id IS NULL DO UPDATE SET
          subnet = EXCLUDED.subnet,
          mac_address = COALESCE(EXCLUDED.mac_address, network_discoveries.mac_address),
          hostname = COALESCE(NULLIF(EXCLUDED.hostname, ''), network_discoveries.hostname),
          last_seen = NOW()
      `, [subnet, ip, mac, hostname || null]);
      saved += result.rowCount;
    }
  }
  return saved;
}

router.post('/report', requireAgentKey, asyncHandler(async (req, res) => {
  const observerId = req.body?.observer_asset_id;
  const devices = req.body?.devices;
  if (typeof observerId !== 'string' || !Array.isArray(devices) || devices.length > 1024) {
    return res.status(400).json({ error: 'A registered observer and up to 1024 discovered devices are required.' });
  }
  const { rows: observer } = await query('SELECT id FROM assets WHERE id = $1', [observerId]);
  if (!observer.length) return res.status(404).json({ error: 'Discovery agent asset is not registered.' });
  const saved = await storeDiscoveries(devices, observerId);
  res.json({ ok: true, received: devices.length, saved });
}));

router.post('/host-report', requireAgentKey, asyncHandler(async (req, res) => {
  const devices = req.body?.devices;
  if (!Array.isArray(devices) || devices.length > 1024) {
    return res.status(400).json({ error: 'Provide up to 1024 discovered devices.' });
  }
  const saved = await storeDiscoveries(devices, null);
  res.json({ ok: true, received: devices.length, saved });
}));

export default router;
