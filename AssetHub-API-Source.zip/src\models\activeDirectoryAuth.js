import { query } from '../config/db.js';

export async function ensureActiveDirectoryAuthSchema() {
  await query(`
    ALTER TABLE users
      ADD COLUMN IF NOT EXISTS ad_employee_id VARCHAR(64),
      ADD COLUMN IF NOT EXISTS auth_provider VARCHAR(24) NOT NULL DEFAULT 'local';
    CREATE UNIQUE INDEX IF NOT EXISTS idx_users_ad_employee_id
      ON users(ad_employee_id) WHERE ad_employee_id IS NOT NULL;
  `);
}
