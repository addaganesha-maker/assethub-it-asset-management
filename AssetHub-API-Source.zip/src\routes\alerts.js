import { Router } from 'express';
import { query } from '../config/db.js';
import { requireAuth, requirePermission } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/error.js';

const router = Router();

router.get(
  '/',
  requireAuth,
  requirePermission('alerts', 'read'),
  asyncHandler(async (req, res) => {
    const { resolved } = req.query;
    const filter = resolved === 'true' ? 'TRUE' : resolved === 'false' ? 'FALSE' : 'NULL';
    const sql = filter === 'NULL'
      ? `SELECT a.*, s.hostname FROM alerts a
         LEFT JOIN assets s ON s.id = a.asset_id
         ORDER BY a.created_at DESC LIMIT 200`
      : `SELECT a.*, s.hostname FROM alerts a
         LEFT JOIN assets s ON s.id = a.asset_id
         WHERE a.is_resolved = ${filter}
         ORDER BY a.created_at DESC LIMIT 200`;
    const { rows } = await query(sql);
    res.json({ data: rows });
  })
);

router.patch(
  '/:id/resolve',
  requireAuth,
  requirePermission('alerts', 'write'),
  asyncHandler(async (req, res) => {
    await query(
      'UPDATE alerts SET is_resolved = TRUE, resolved_at = NOW() WHERE id = $1',
      [req.params.id]
    );
    res.json({ ok: true });
  })
);

router.get(
  '/rules',
  requireAuth,
  requirePermission('alerts', 'read'),
  asyncHandler(async (_req, res) => {
    const { rows } = await query('SELECT * FROM alert_rules ORDER BY id');
    res.json({ data: rows });
  })
);

router.patch(
  '/rules/:id',
  requireAuth,
  requirePermission('alerts', 'write'),
  asyncHandler(async (req, res) => {
    const { threshold, severity, is_active, duration_sec } = req.body;
    await query(
      `UPDATE alert_rules SET
         threshold = COALESCE($1, threshold),
         severity  = COALESCE($2, severity),
         is_active = COALESCE($3, is_active),
         duration_sec = COALESCE($4, duration_sec)
       WHERE id = $5`,
      [threshold, severity, is_active, duration_sec, req.params.id]
    );
    res.json({ ok: true });
  })
);

export default router;