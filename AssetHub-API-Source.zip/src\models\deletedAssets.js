import { query } from '../config/db.js';

export async function ensureDeletedAssetsSchema() {
  await query(`
    CREATE TABLE IF NOT EXISTS deleted_assets (
      id BIGSERIAL PRIMARY KEY,
      original_asset_id UUID NOT NULL,
      hostname VARCHAR(255) NOT NULL,
      asset_tag VARCHAR(32),
      deleted_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      deleted_by_email VARCHAR(255),
      deleted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      snapshot JSONB NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_deleted_assets_deleted_at
      ON deleted_assets(deleted_at DESC);
  `);
}
