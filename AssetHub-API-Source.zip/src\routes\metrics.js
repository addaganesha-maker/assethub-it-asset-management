import { Router } from 'express';
import { requireAuth, requireAgentKey, requirePermission } from '../middleware/auth.js';
import { query } from '../config/db.js';
import { asyncHandler } from '../middleware/error.js';
import { bufferMetric } from '../services/metricsBuffer.js';
import { evaluate } from '../services/alertEngine.js';

const router = Router();

/**
 * AGENT: push a metric sample.
 */
router.post(
  '/',
  requireAgentKey,
  asyncHandler(async (req, res) => {
    const m = req.body;
    if (!m.asset_id) return res.status(400).json({ error: 'asset_id required' });

    bufferMetric(m);

    // Update last_seen and quick stats on asset row
    await query(
      `UPDATE assets
       SET last_seen = NOW(),
           status = 'active',
           disk_free_gb = COALESCE($2, disk_free_gb),
           uptime_seconds = COALESCE($3, uptime_seconds)
       WHERE id = $1`,
      [m.asset_id, m.disk_free_gb, m.uptime_seconds]
    );

    // Fire alert rules (async, best-effort)
    evaluate(m).catch((e) => console.error('alert eval', e));

    const io = req.app.get('io');
    if (io) {
      io.to(`asset:${m.asset_id}`).emit('live-update', m);
      io.to('admins').emit('live-update', m);
    }

    res.json({ ok: true });
  })
);

/**
 * ADMIN: Time-series for one asset.
 */
router.get(
  '/:assetId',
  requireAuth,
  requirePermission('assets', 'read'),
  asyncHandler(async (req, res) => {
    const { range = '1h' } = req.query;
    const map = { '1h': '1 hour', '24h': '24 hours', '7d': '7 days', '30d': '30 days' };
    const interval = map[range] || '1 hour';

    const { rows } = await query(
      `SELECT time, cpu_percent, ram_percent, disk_percent,
              net_rx_bytes, net_tx_bytes, process_count, logged_user
       FROM asset_metrics
       WHERE asset_id = $1 AND time > NOW() - INTERVAL '${interval}'
       ORDER BY time ASC`,
      [req.params.assetId]
    );
    res.json({ data: rows });
  })
);

export default router;