import { spawn } from 'node:child_process';
import { reverse } from 'node:dns/promises';
import { query } from '../config/db.js';

const INTERVAL_MS = 15 * 60 * 1000;
const MAX_TARGETS = 4096;
const PING_CONCURRENCY = 64;
const scanState = { running: false, last_started_at: null, last_completed_at: null, last_result: null };
let interval;

function ipv4ToNumber(value) {
  const parts = value.split('.').map(Number);
  if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return null;
  return parts.reduce((result, part) => result * 256 + part, 0);
}

function isUsableIPv4(value) {
  const [first, second] = value.split('.').map(Number);
  return first !== 0 && first !== 127 && first < 224
    && !(first === 169 && second === 254)
    && value !== '255.255.255.255';
}

function configuredTargets(rows) {
  const targets = new Map();
  for (const row of rows) {
    const [address, prefixText] = row.subnet.split('/');
    const prefix = Number(prefixText);
    const addressNumber = ipv4ToNumber(address);
    if (addressNumber === null || !isUsableIPv4(address) || !Number.isInteger(prefix) || prefix < 20 || prefix > 32) continue;

    const size = 2 ** (32 - prefix);
    const network = Math.floor(addressNumber / size) * size;
    const first = prefix < 31 ? network + 1 : network;
    const last = prefix < 31 ? network + size - 2 : network + size - 1;
    if (last < first) continue;
    for (let target = first; target <= last; target += 1) {
      const ip = [Math.floor(target / 16777216), Math.floor(target / 65536) % 256,
        Math.floor(target / 256) % 256, target % 256].join('.');
      if (!isUsableIPv4(ip) || targets.has(ip)) continue;
      if (targets.size >= MAX_TARGETS) return { targets, limitExceeded: true };
      targets.set(ip, row.subnet);
    }
  }
  return { targets, limitExceeded: false };
}

function ping(ip) {
  return new Promise((resolve) => {
    const isWindows = process.platform === 'win32';
    const args = isWindows ? ['/n', '1', '/w', '900', ip] : ['-c', '1', '-W', '1', ip];
    let child;
    try {
      child = spawn(isWindows ? 'ping' : 'ping', args, { stdio: 'ignore', windowsHide: true });
    } catch {
      resolve(false);
      return;
    }
    const timeout = setTimeout(() => child.kill(), 1500);
    child.once('error', () => { clearTimeout(timeout); resolve(false); });
    child.once('close', (code) => { clearTimeout(timeout); resolve(code === 0); });
  });
}

async function hostnameFor(ip) {
  let timeout;
  try {
    const names = await Promise.race([
      reverse(ip),
      new Promise((_, reject) => { timeout = setTimeout(() => reject(new Error('DNS lookup timed out')), 1000); }),
    ]);
    return names[0]?.replace(/\.$/, '') || null;
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

async function storeTarget(ip, subnet, hostname) {
  await query(`
    INSERT INTO network_discoveries (observer_asset_id, subnet, ip_address, hostname)
    VALUES (NULL, $1::cidr, $2::inet, $3)
    ON CONFLICT (ip_address) WHERE observer_asset_id IS NULL DO UPDATE SET
      subnet = EXCLUDED.subnet,
      hostname = COALESCE(NULLIF(EXCLUDED.hostname, ''), network_discoveries.hostname),
      last_seen = NOW()
  `, [subnet, ip, hostname]);
}

export async function runNetworkDiscoveryScan() {
  if (scanState.running) return { ...scanState, skipped: true };
  scanState.running = true;
  scanState.last_started_at = new Date().toISOString();
  try {
    const { rows } = await query(`
      SELECT s.name, ss.subnet::text AS subnet
      FROM site_subnets ss JOIN sites s ON s.id = ss.site_id
      ORDER BY masklen(ss.subnet) DESC, s.name
    `);
    const { targets, limitExceeded } = configuredTargets(rows);
    if (limitExceeded) throw new Error(`Configured site ranges exceed the ${MAX_TARGETS.toLocaleString()}-target scan limit.`);
    const list = [...targets.entries()];
    let cursor = 0;
    let discovered = 0;
    const workers = Array.from({ length: Math.min(PING_CONCURRENCY, list.length) }, async () => {
      while (cursor < list.length) {
        const [ip, subnet] = list[cursor++];
        if (!await ping(ip)) continue;
        await storeTarget(ip, subnet, await hostnameFor(ip));
        discovered += 1;
      }
    });
    await Promise.all(workers);
    scanState.last_result = { targets: list.length, discovered };
  } catch (error) {
    scanState.last_result = { error: error.message || 'Network discovery scan failed.' };
    console.error('[network-discovery] scheduled scan failed:', error.message);
  } finally {
    scanState.running = false;
    scanState.last_completed_at = new Date().toISOString();
  }
  return { ...scanState };
}

export function getNetworkDiscoveryStatus() {
  return { ...scanState, interval_minutes: INTERVAL_MS / 60000 };
}

export function startNetworkDiscoveryJob() {
  if (interval) return;
  void runNetworkDiscoveryScan();
  interval = setInterval(() => { void runNetworkDiscoveryScan(); }, INTERVAL_MS);
}
