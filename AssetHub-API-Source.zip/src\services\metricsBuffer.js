import { query, pool } from '../config/db.js';

const buffer = [];
const MAX = 500;
const FLUSH_MS = 5000;

export function bufferMetric(m) {
  buffer.push(m);
  if (buffer.length >= MAX) flush();
}

export async function flush() {
  if (!buffer.length) return;
  const batch = buffer.splice(0, buffer.length);
  const values = [];
  const placeholders = [];
  let i = 1;
  for (const m of batch) {
    placeholders.push(
      `($${i++}, $${i++}, $${i++}, $${i++}, $${i++}, $${i++}, $${i++}, $${i++}, $${i++}, $${i++})`
    );
    values.push(
      m.asset_id,
      m.cpu_percent ?? null,
      m.ram_percent ?? null,
      m.ram_used_gb ?? null,
      m.disk_percent ?? null,
      m.disk_free_gb ?? null,
      m.net_rx_bytes ?? null,
      m.net_tx_bytes ?? null,
      m.process_count ?? null,
      m.logged_user ?? null
    );
  }
  try {
    await query(
      `INSERT INTO asset_metrics
         (asset_id, cpu_percent, ram_percent, ram_used_gb, disk_percent,
          disk_free_gb, net_rx_bytes, net_tx_bytes, process_count, logged_user)
       VALUES ${placeholders.join(',')}`,
      values
    );
  } catch (e) {
    console.error('metrics flush error', e.message);
  }
}

export function startMetricsFlusher() {
  setInterval(flush, FLUSH_MS);

  // Mark offline assets that haven't been seen for 5 minutes
  setInterval(async () => {
    try {
      await query(
        `UPDATE assets SET status = 'offline'
         WHERE status = 'active'
           AND last_seen < NOW() - INTERVAL '5 minutes'`
      );
    } catch (e) {
      console.error('offline sweep error', e.message);
    }
  }, 60_000);
}