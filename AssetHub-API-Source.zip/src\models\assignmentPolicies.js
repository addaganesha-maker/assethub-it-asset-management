import { query } from '../config/db.js';

export async function ensureAssignmentPolicySchema() {
  await query(`
    ALTER TABLE asset_assignment_history
      ADD COLUMN IF NOT EXISTS policy_snapshot JSONB;

    UPDATE asset_assignment_history h
    SET policy_snapshot = jsonb_set(
      jsonb_set(
        jsonb_set(
          h.policy_snapshot,
          '{asset,asset_tag}',
          COALESCE(to_jsonb(COALESCE(NULLIF(a.asset_tag, ''), a.tags->>0)), 'null'::jsonb),
          TRUE
        ),
        '{asset,asset_tags}',
        COALESCE(a.tags, '[]'::jsonb),
        TRUE
      ),
      '{employee,division}',
      COALESCE(to_jsonb(s.division), 'null'::jsonb),
      TRUE
    )
    FROM assets a
    LEFT JOIN staff_users s ON s.id = a.assigned_user_id
    WHERE h.asset_id = a.id
      AND a.lifecycle_status = 'issued'
      AND h.event_type = 'issued'
      AND h.policy_snapshot IS NOT NULL
      AND h.id = (
        SELECT latest.id
        FROM asset_assignment_history latest
        WHERE latest.asset_id = a.id AND latest.event_type = 'issued'
        ORDER BY latest.occurred_at DESC, latest.id DESC
        LIMIT 1
      )
      AND (NOT (h.policy_snapshot->'asset' ? 'asset_tags')
        OR NOT (h.policy_snapshot->'employee' ? 'division'));
  `);
}
