import { pool } from '../config/db.js';

export async function ensureAssetLifecycleSchema() {
  await pool.query(`
    ALTER TABLE assets
      ADD COLUMN IF NOT EXISTS purchase_date DATE,
      ADD COLUMN IF NOT EXISTS warranty_end_date DATE,
      ADD COLUMN IF NOT EXISTS warranty_checked_at TIMESTAMPTZ;
    CREATE INDEX IF NOT EXISTS idx_assets_warranty_end_date ON assets(warranty_end_date);
  `);
}
