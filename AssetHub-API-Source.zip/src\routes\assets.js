import { Router } from 'express';
import { pool, query } from '../config/db.js';
import { requireAuth, requireAgentKey, requireAnyPermission, requirePermission } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/error.js';
import { fetchWarrantyEndDate } from '../services/warrantyLookup.js';

const router = Router();

const assetIdPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const normalizeTag = (value) => typeof value === 'string' ? value.trim().replace(/\s+/g, ' ') : '';

/** PUBLIC: QR-scannable, read-only asset record. The QR link grants access to these details. */
router.get('/public/:id', asyncHandler(async (req, res) => {
  if (!assetIdPattern.test(req.params.id)) return res.status(404).json({ error: 'Asset not found' });
  const { rows } = await query('SELECT * FROM assets WHERE id = $1', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Asset not found' });
  const [software, locationHistory, assignmentHistory] = await Promise.all([
    query(`SELECT software_name AS name, version, publisher, install_date, product_code
           FROM installed_software WHERE asset_id = $1 ORDER BY software_name`, [req.params.id]),
    query(`SELECT latitude, longitude, accuracy_m, captured_at
           FROM asset_location_history WHERE asset_id = $1 ORDER BY captured_at DESC, id DESC LIMIT 100`, [req.params.id]),
    query(`SELECT * FROM asset_assignment_history WHERE asset_id = $1 ORDER BY occurred_at DESC LIMIT 100`, [req.params.id]),
  ]);
  res.set('Cache-Control', 'no-store');
  res.json({ ...rows[0], software: software.rows, location_history: locationHistory.rows, assignment_history: assignmentHistory.rows });
}));

/** ADMIN: Review deleted assets and their archived inventory/history. */
router.get('/deleted', requireAuth, requirePermission('deleted_assets', 'read'), asyncHandler(async (_req, res) => {
  const { rows } = await query(
    `SELECT id, original_asset_id, hostname, asset_tag, deleted_by_email, deleted_at, snapshot
     FROM deleted_assets ORDER BY deleted_at DESC LIMIT 500`
  );
  res.json({ data: rows });
}));

/** ADMIN: List the tag catalog and how many assets use each tag. */
router.get('/tags', requireAuth, requirePermission('asset_tags', 'read'), asyncHandler(async (_req, res) => {
  const { rows } = await query(`
    SELECT t.id, t.name, t.created_at, COUNT(a.id)::int AS asset_count
    FROM asset_tag_catalog t
    LEFT JOIN assets a ON COALESCE(a.tags, '[]'::jsonb) ? t.name
    GROUP BY t.id
    ORDER BY LOWER(t.name), t.name
  `);
  res.json({ data: rows });
}));

/** ADMIN: Add one tag name to the catalog. */
router.post('/tags', requireAuth, requirePermission('asset_tags', 'write'), asyncHandler(async (req, res) => {
  const name = normalizeTag(req.body?.name);
  if (!name) return res.status(400).json({ error: 'Tag name is required' });
  if (name.length > 64 || /[\x00-\x1f]/.test(name)) return res.status(400).json({ error: 'Tag name must be 1–64 characters' });
  const { rows } = await query(
    'INSERT INTO asset_tag_catalog (name) VALUES ($1) ON CONFLICT DO NOTHING RETURNING id, name, created_at',
    [name]
  );
  if (!rows.length) return res.status(409).json({ error: 'A tag with this name already exists' });
  res.status(201).json(rows[0]);
}));

/** ADMIN: Import tag names in one request (up to 500 names). */
router.post('/tags/import', requireAuth, requirePermission('asset_tags', 'write'), asyncHandler(async (req, res) => {
  if (!Array.isArray(req.body?.tags) || req.body.tags.length > 500) {
    return res.status(400).json({ error: 'Provide a list of up to 500 tag names' });
  }
  const tags = [...new Set(req.body.tags.map(normalizeTag).filter((name) => name && name.length <= 64 && !/[\x00-\x1f]/.test(name)))];
  if (!tags.length) return res.status(400).json({ error: 'No valid tag names found' });
  const values = [];
  const placeholders = tags.map((name, index) => {
    values.push(name);
    return `($${index + 1})`;
  });
  const { rows } = await query(
    `INSERT INTO asset_tag_catalog (name) VALUES ${placeholders.join(', ')}
     ON CONFLICT DO NOTHING RETURNING name`,
    values
  );
  res.json({ created: rows.length, skipped: tags.length - rows.length });
}));

/** ADMIN: Add or remove one catalog tag from many assets. */
router.post('/tags/assign', requireAuth, requirePermission('asset_tags', 'write'), asyncHandler(async (req, res) => {
  const assetIds = Array.isArray(req.body?.asset_ids) ? [...new Set(req.body.asset_ids)] : [];
  const tagNameInput = normalizeTag(req.body?.tag_name);
  const action = req.body?.action;
  if (!assetIds.length || assetIds.length > 500 || assetIds.some((id) => typeof id !== 'string' || !assetIdPattern.test(id))) {
    return res.status(400).json({ error: 'Select 1–500 valid assets' });
  }
  if (!['add', 'remove', 'replace'].includes(action)) return res.status(400).json({ error: 'Action must be add, remove, or replace' });
  const { rows: tagRows } = await query(
    'SELECT name FROM asset_tag_catalog WHERE LOWER(name) = LOWER($1) LIMIT 1',
    [tagNameInput]
  );
  if (!tagRows.length) return res.status(404).json({ error: 'Choose a tag from the tag catalog' });
  const tagName = tagRows[0].name;
  const { rows } = await query(`
    WITH updated_assets AS (
      UPDATE assets SET tags = CASE
        WHEN $2 = 'replace' THEN jsonb_build_array($1::text)
        WHEN $2 = 'add' THEN (
          SELECT COALESCE(jsonb_agg(tag_name), '[]'::jsonb) FROM (
            SELECT jsonb_array_elements_text(COALESCE(assets.tags, '[]'::jsonb)) AS tag_name
            UNION SELECT $1::text
          ) AS merged_tags
        )
        ELSE COALESCE((
          SELECT jsonb_agg(existing.tag_name)
          FROM jsonb_array_elements_text(COALESCE(assets.tags, '[]'::jsonb)) AS existing(tag_name)
          WHERE existing.tag_name <> $1
        ), '[]'::jsonb)
      END, updated_at = NOW()
      WHERE id = ANY($3::uuid[])
      RETURNING id, asset_tag, tags, lifecycle_status
    ),
    latest_issued AS (
      SELECT DISTINCT ON (h.asset_id) h.id, h.asset_id
      FROM asset_assignment_history h
      JOIN updated_assets a ON a.id = h.asset_id AND a.lifecycle_status = 'issued'
      WHERE h.event_type = 'issued' AND h.policy_snapshot IS NOT NULL
      ORDER BY h.asset_id, h.occurred_at DESC, h.id DESC
    ),
    synced_policies AS (
      UPDATE asset_assignment_history h
      SET policy_snapshot = jsonb_set(
        jsonb_set(
          h.policy_snapshot,
          '{asset,asset_tag}',
          COALESCE(to_jsonb(COALESCE(NULLIF(a.asset_tag, ''), a.tags->>0)), 'null'::jsonb),
          TRUE
        ),
        '{asset,asset_tags}',
        COALESCE(a.tags, '[]'::jsonb),
        TRUE
      )
      FROM latest_issued latest
      JOIN updated_assets a ON a.id = latest.asset_id
      WHERE h.id = latest.id
      RETURNING h.id
    )
    SELECT updated_assets.id
    FROM updated_assets
    CROSS JOIN (SELECT COUNT(*) FROM synced_policies) AS policy_sync
  `, [tagName, action, assetIds]);
  res.json({ updated: rows.length, tag: tagName, action });
}));

/**
 * AGENT: Register or update inventory.
 * Called by the client agent on first boot and periodically.
 */
router.post(
  '/inventory',
  requireAgentKey,
  asyncHandler(async (req, res) => {
    const d = req.body;
    if (!d.hostname) return res.status(400).json({ error: 'hostname required' });
    const coordinate = (value, min, max) => typeof value === 'number'
      && Number.isFinite(value) && value >= min && value <= max ? value : null;
    let latitude = coordinate(d.latitude, -90, 90);
    let longitude = coordinate(d.longitude, -180, 180);
    if (latitude === null || longitude === null) {
      latitude = null;
      longitude = null;
    }
    const locationAccuracy = latitude !== null && longitude !== null
      ? coordinate(d.location_accuracy_m, 0, 1000000)
      : null;
    const installedAt = typeof d.agent_installed_at === 'string'
      && Number.isFinite(Date.parse(d.agent_installed_at))
      ? new Date(d.agent_installed_at).toISOString()
      : null;

    const sql = `
      INSERT INTO assets (
        hostname, asset_type, os_name, os_version, os_build, architecture,
        ip_address, mac_address, cpu_model, cpu_cores, ram_gb,
        disk_total_gb, disk_free_gb, gpu_model, serial_number,
        manufacturer, model, bios_version, uptime_seconds, logged_in_user,
        logged_in_domain, domain_name, domain_joined, workgroup_name, outlook_email, onedrive_email,
        system_type, system_uuid, storage_devices, network_adapters, monitor_devices, user_session_seen_at, last_seen,
        agent_version, agent_installed_at, latitude, longitude, location_accuracy_m, location_updated_at
      ) VALUES (
        $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,
        $20,$21,$22,$23,$24,$25,$26,$27,$28,COALESCE($29::jsonb, '[]'::jsonb),
        COALESCE($30::jsonb, '[]'::jsonb),COALESCE($31::jsonb, '[]'::jsonb),NOW(),NOW(),NULLIF($32, ''),
        COALESCE($33::timestamptz, NOW()),$34::double precision,$35::double precision,$36::double precision,
        CASE WHEN $34::double precision IS NOT NULL AND $35::double precision IS NOT NULL THEN NOW() ELSE NULL END
      )
      ON CONFLICT (mac_address) DO UPDATE SET
        hostname       = EXCLUDED.hostname,
        asset_type     = CASE WHEN assets.asset_type IN ('workstation', 'laptop', 'tablet') THEN EXCLUDED.asset_type ELSE assets.asset_type END,
        os_name        = EXCLUDED.os_name,
        os_version     = EXCLUDED.os_version,
        os_build       = EXCLUDED.os_build,
        architecture   = EXCLUDED.architecture,
        ip_address     = EXCLUDED.ip_address,
        cpu_model      = EXCLUDED.cpu_model,
        cpu_cores      = EXCLUDED.cpu_cores,
        ram_gb         = EXCLUDED.ram_gb,
        disk_total_gb  = EXCLUDED.disk_total_gb,
        disk_free_gb   = EXCLUDED.disk_free_gb,
        gpu_model      = EXCLUDED.gpu_model,
        serial_number  = EXCLUDED.serial_number,
        manufacturer   = EXCLUDED.manufacturer,
        model          = EXCLUDED.model,
        bios_version   = EXCLUDED.bios_version,
        logged_in_user = EXCLUDED.logged_in_user,
        logged_in_domain = EXCLUDED.logged_in_domain,
        domain_name    = EXCLUDED.domain_name,
        domain_joined  = EXCLUDED.domain_joined,
        workgroup_name = EXCLUDED.workgroup_name,
        outlook_email = COALESCE(EXCLUDED.outlook_email, assets.outlook_email),
        onedrive_email = COALESCE(EXCLUDED.onedrive_email, assets.onedrive_email),
        system_type    = EXCLUDED.system_type,
        system_uuid    = EXCLUDED.system_uuid,
        storage_devices = COALESCE($29::jsonb, assets.storage_devices),
        network_adapters = COALESCE($30::jsonb, assets.network_adapters),
        monitor_devices = COALESCE($31::jsonb, assets.monitor_devices),
        agent_version = COALESCE(NULLIF(EXCLUDED.agent_version, ''), assets.agent_version),
        agent_installed_at = COALESCE(assets.agent_installed_at, EXCLUDED.agent_installed_at),
        latitude = COALESCE(EXCLUDED.latitude, assets.latitude),
        longitude = COALESCE(EXCLUDED.longitude, assets.longitude),
        location_accuracy_m = CASE
          WHEN EXCLUDED.latitude IS NOT NULL AND EXCLUDED.longitude IS NOT NULL
          THEN EXCLUDED.location_accuracy_m ELSE assets.location_accuracy_m END,
        location_updated_at = CASE
          WHEN EXCLUDED.latitude IS NOT NULL AND EXCLUDED.longitude IS NOT NULL
          THEN NOW() ELSE assets.location_updated_at END,
        uptime_seconds = EXCLUDED.uptime_seconds,
        user_session_seen_at = NOW(),
        status         = 'active',
        last_seen      = NOW(),
        updated_at     = NOW()
      RETURNING id, (xmax = 0) AS is_new;
    `;

    const params = [
      d.hostname, d.asset_type || 'workstation', d.os_name, d.os_version,
      d.os_build, d.architecture, d.ip_address, d.mac_address, d.cpu_model,
      d.cpu_cores, d.ram_gb, d.disk_total_gb, d.disk_free_gb, d.gpu_model,
      d.serial_number, d.manufacturer, d.model, d.bios_version, d.uptime_seconds,
      d.logged_in_user || null, d.logged_in_domain || null, d.domain_name || null,
      d.domain_joined === true, d.workgroup_name || null,
      d.outlook_email || null, d.onedrive_email || null, d.system_type || null,
      d.system_uuid || null,
      Array.isArray(d.storage_devices) ? JSON.stringify(d.storage_devices.slice(0, 32)) : null,
      Array.isArray(d.network_adapters) ? JSON.stringify(d.network_adapters.slice(0, 32)) : null,
      Array.isArray(d.monitor_devices) ? JSON.stringify(d.monitor_devices.slice(0, 16)) : null,
      typeof d.agent_version === 'string' ? d.agent_version.trim().slice(0, 64) : '',
      installedAt,
      latitude,
      longitude,
      latitude !== null && longitude !== null ? locationAccuracy : null,
    ];

    const { rows } = await query(sql, params);
    const assetId = rows[0].id;
    if (latitude !== null && longitude !== null) {
      await query(`
        WITH latest AS (
          SELECT latitude, longitude
          FROM asset_location_history
          WHERE asset_id = $1
          ORDER BY captured_at DESC, id DESC
          LIMIT 1
        )
        INSERT INTO asset_location_history (asset_id, latitude, longitude, accuracy_m)
        SELECT $1, $2::double precision, $3::double precision, $4::double precision
        WHERE NOT EXISTS (
          SELECT 1 FROM latest
          WHERE ROUND(latest.latitude::numeric, 5) = ROUND(($2::double precision)::numeric, 5)
            AND ROUND(latest.longitude::numeric, 5) = ROUND(($3::double precision)::numeric, 5)
        )
      `, [assetId, latitude, longitude, locationAccuracy]);
    }
    if (rows[0].is_new) {
      await query(
        `INSERT INTO asset_assignment_history (asset_id, event_type, notes)
         VALUES ($1, 'stocked', 'Device registered by agent')`,
        [assetId]
      );
    }

    // Replace software inventory
    if (Array.isArray(d.software)) {
      await query('DELETE FROM installed_software WHERE asset_id = $1', [assetId]);
      const values = [];
      const placeholders = [];
      let i = 1;
      for (const s of d.software.slice(0, 2000)) {
        placeholders.push(`($${i++},$${i++},$${i++},$${i++},$${i++},$${i++})`);
        values.push(assetId, s.name, s.version || null, s.publisher || null, s.install_date || null, s.product_code || null);
      }
      if (placeholders.length) {
        await query(
          `INSERT INTO installed_software
             (asset_id, software_name, version, publisher, install_date, product_code)
           VALUES ${placeholders.join(',')}
           ON CONFLICT (asset_id, software_name, version) DO NOTHING`,
          values
        );
      }
    }

    res.json({ ok: true, assetId });
  })
);

/**
 * AGENT: Refresh current interactive user/domain without resending full software inventory.
 */
router.post(
  '/session',
  requireAgentKey,
  asyncHandler(async (req, res) => {
    const d = req.body;
    const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    if (typeof d.asset_id !== 'string' || !uuidPattern.test(d.asset_id)) {
      return res.status(400).json({ error: 'valid asset_id required' });
    }
    const optionalText = (value, max) => typeof value === 'string' && value.trim()
      ? value.trim().slice(0, max)
      : null;
    const { rows } = await query(
      `UPDATE assets SET
         logged_in_user = $2,
         logged_in_domain = $3,
         domain_name = $4,
         domain_joined = $5,
         workgroup_name = $6,
         outlook_email = COALESCE($7, outlook_email),
         onedrive_email = COALESCE($8, onedrive_email),
         user_session_seen_at = NOW(),
         updated_at = NOW()
       WHERE id = $1
       RETURNING id`,
      [
        d.asset_id,
        optionalText(d.logged_in_user, 255),
        optionalText(d.logged_in_domain, 255),
        optionalText(d.domain_name, 255),
        d.domain_joined === true,
        optionalText(d.workgroup_name, 255),
        optionalText(d.outlook_email, 255),
        optionalText(d.onedrive_email, 255),
      ]
    );
    if (!rows.length) return res.status(404).json({ error: 'Asset not registered' });
    res.json({ ok: true });
  })
);

/**
 * ADMIN: List assets with filters.
 */
router.get(
  '/',
  requireAuth,
  requireAnyPermission(['assets', 'read'], ['dashboard', 'read'], ['deployments', 'read']),
  asyncHandler(async (req, res) => {
    const { status, search, limit = 100, offset = 0 } = req.query;
    const stockSection = String(req.query.stock_section || '').trim();
    const where = [];
    const params = [];
    let i = 1;

    if (status) { where.push(`status = $${i++}`); params.push(status); }
    if (stockSection && ['main', 'spare', 'standby'].includes(stockSection)) {
      where.push(`stock_section = $${i++}`);
      params.push(stockSection);
    }
    if (search) {
      where.push(`(
        hostname ILIKE $${i} OR ip_address ILIKE $${i} OR assigned_user ILIKE $${i}
        OR logged_in_user ILIKE $${i} OR logged_in_domain ILIKE $${i}
        OR outlook_email ILIKE $${i} OR onedrive_email ILIKE $${i}
        OR domain_name ILIKE $${i} OR workgroup_name ILIKE $${i}
        OR manufacturer ILIKE $${i} OR model ILIKE $${i}
        OR serial_number ILIKE $${i} OR asset_tag ILIKE $${i}
      )`);
      params.push(`%${search}%`);
      i++;
    }
    if (req.query.tag) {
      where.push(`COALESCE(tags, '[]'::jsonb) ? $${i++}`);
      params.push(String(req.query.tag).slice(0, 64));
    }

    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    params.push(limit, offset);

    const { rows } = await query(
      `SELECT * FROM assets ${whereSql}
       ORDER BY last_seen DESC NULLS LAST
       LIMIT $${i++} OFFSET $${i}`,
      params
    );

    const { rows: count } = await query(
      `SELECT COUNT(*)::int AS total FROM assets ${whereSql}`,
      params.slice(0, params.length - 2)
    );

    res.json({ data: rows, total: count[0].total });
  })
);

/**
 * ADMIN: Dashboard KPIs.
 */
router.get(
  '/stats/summary',
  requireAuth,
  requirePermission('dashboard', 'read'),
  asyncHandler(async (_req, res) => {
    const { rows } = await query(`
      SELECT
        COUNT(*)::int                                              AS total,
        COUNT(*) FILTER (WHERE status = 'active')::int             AS online,
        COUNT(*) FILTER (WHERE status = 'offline')::int            AS offline,
        COUNT(*) FILTER (WHERE last_seen > NOW() - INTERVAL '5 min')::int AS active_now,
        COUNT(*) FILTER (WHERE lifecycle_status = 'stock' AND status <> 'retired')::int AS ready_to_issue,
        COUNT(*) FILTER (WHERE lifecycle_status = 'issued' AND status <> 'retired')::int AS issued,
        COUNT(*) FILTER (WHERE warranty_end_date >= CURRENT_DATE)::int AS warranty_in,
        COUNT(*) FILTER (WHERE warranty_end_date < CURRENT_DATE)::int AS warranty_out,
        COALESCE(SUM(ram_gb),0)::numeric                           AS total_ram_gb,
        COALESCE(SUM(disk_total_gb),0)::numeric                    AS total_disk_gb
      FROM assets
    `);
    const { rows: alertRows } = await query(
      `SELECT COUNT(*)::int AS open_alerts
       FROM alerts WHERE is_resolved = FALSE`
    );
    res.json({ ...rows[0], ...alertRows[0] });
  })
);

/** ADMIN: Connected monitor and laptop-panel inventory reported by Windows agents. */
router.get('/monitors', requireAuth, requirePermission('assets', 'read'), asyncHandler(async (_req, res) => {
  const { rows } = await query(`
    SELECT a.id AS asset_id, a.hostname, a.asset_tag, a.asset_type,
           a.manufacturer AS computer_manufacturer, a.model AS computer_model,
           a.last_seen,
           display->>'instance_name' AS instance_name,
           display->>'manufacturer' AS monitor_manufacturer,
           display->>'model' AS monitor_model,
           display->>'serial_number' AS monitor_serial_number,
           NULLIF(display->>'size_inches', '')::numeric AS size_inches,
           NULLIF(display->>'width_cm', '')::numeric AS width_cm,
           NULLIF(display->>'height_cm', '')::numeric AS height_cm,
           NULLIF(display->>'year_of_manufacture', '')::int AS year_of_manufacture,
           NULLIF(display->>'week_of_manufacture', '')::int AS week_of_manufacture,
           COALESCE((display->>'active')::boolean, TRUE) AS active
    FROM assets a
    CROSS JOIN LATERAL jsonb_array_elements(COALESCE(a.monitor_devices, '[]'::jsonb)) AS monitor_rows(display)
    ORDER BY a.hostname, monitor_manufacturer, monitor_model
  `);
  const data = rows.map((monitor) => ({ ...monitor, size_inches: monitor.size_inches == null ? null : Number(monitor.size_inches) }));
  res.json({
    data,
    summary: {
      total_monitors: data.length,
      known_serials: data.filter((monitor) => monitor.monitor_serial_number).length,
      known_sizes: data.filter((monitor) => monitor.size_inches).length,
      laptop_displays: data.filter((monitor) => /laptop|notebook/i.test(monitor.asset_type || '')).length,
    },
  });
}));

/** ADMIN: Open the manufacturer's public warranty page and read its visible result. */
router.post('/:id/warranty-lookup', requireAuth, requirePermission('assets', 'write'), asyncHandler(async (req, res) => {
  const { rows } = await query('SELECT id, asset_type, manufacturer, model, serial_number FROM assets WHERE id = $1', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Asset not found.' });
  const result = await fetchWarrantyEndDate(rows[0]);
  const { rows: updated } = await query(
    `UPDATE assets SET warranty_end_date = $1, warranty_checked_at = NOW(), updated_at = NOW()
     WHERE id = $2 RETURNING warranty_end_date, warranty_checked_at`,
    [result.warrantyEndDate, req.params.id]
  );
  res.json({ ...updated[0], source_url: result.sourceUrl });
}));

/**
 * ADMIN: Single asset with software.
 */
router.get(
  '/:id',
  requireAuth,
  requireAnyPermission(['assets', 'read'], ['deployments', 'read']),
  asyncHandler(async (req, res) => {
    const { rows } = await query('SELECT * FROM assets WHERE id = $1', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Not found' });

    const [software, locationHistory] = await Promise.all([
      query(
        `SELECT software_name AS name, version, publisher, install_date, product_code
         FROM installed_software WHERE asset_id = $1 ORDER BY software_name`,
        [req.params.id]
      ),
      query(
        `SELECT latitude, longitude, accuracy_m, captured_at
         FROM asset_location_history
         WHERE asset_id = $1
         ORDER BY captured_at DESC, id DESC
         LIMIT 100`,
        [req.params.id]
      ),
    ]);
    res.json({ ...rows[0], software: software.rows, location_history: locationHistory.rows });
  })
);

/**
 * ADMIN: Update fields.
 */
router.patch(
  '/:id',
  requireAuth,
  requirePermission('assets', 'write'),
  asyncHandler(async (req, res) => {
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    if ('stock_section' in body) {
      const stockSection = typeof body.stock_section === 'string' ? body.stock_section.trim().toLowerCase() : '';
      if (!['main', 'spare', 'standby'].includes(stockSection)) {
        return res.status(400).json({ error: 'Stock section must be main, spare, or standby.' });
      }
      const { rows } = await query(
        `UPDATE assets SET stock_section = $1, updated_at = NOW()
         WHERE id = $2
         RETURNING id, stock_section`,
        [stockSection, req.params.id]
      );
      if (!rows.length) return res.status(404).json({ error: 'Asset not found.' });
      return res.json({ ok: true, stock_section: rows[0].stock_section });
    }

    if ('asset_tag' in body) {
      if (body.asset_tag !== null && typeof body.asset_tag !== 'string') {
        return res.status(400).json({ error: 'Inventory ID must be text.' });
      }
      const assetTag = typeof body.asset_tag === 'string' ? body.asset_tag.trim() || null : null;
      if (assetTag && (assetTag.length > 32 || /[\x00-\x1f]/.test(assetTag))) {
        return res.status(400).json({ error: 'Inventory ID must be 1–32 printable characters.' });
      }

      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const { rows } = await client.query(
          `UPDATE assets SET asset_tag = $1, updated_at = NOW()
           WHERE id = $2
           RETURNING id, lifecycle_status`,
          [assetTag, req.params.id]
        );
        if (!rows.length) {
          await client.query('ROLLBACK');
          return res.status(404).json({ error: 'Asset not found.' });
        }
        if (rows[0].lifecycle_status === 'issued') {
          await client.query(
            `UPDATE asset_assignment_history
             SET policy_snapshot = jsonb_set(
               policy_snapshot,
               '{asset,asset_tag}',
               COALESCE(to_jsonb($1::text), 'null'::jsonb),
               TRUE
             )
             WHERE id = (
               SELECT id FROM asset_assignment_history
               WHERE asset_id = $2 AND event_type = 'issued'
               ORDER BY occurred_at DESC
               LIMIT 1
             )
             AND policy_snapshot IS NOT NULL`,
            [assetTag, req.params.id]
          );
        }
        await client.query('COMMIT');
        return res.json({ ok: true, asset_tag: assetTag });
      } catch (error) {
        await client.query('ROLLBACK');
        if (error.code === '23505') {
          return res.status(409).json({ error: 'This inventory ID is already assigned to another asset.' });
        }
        throw error;
      } finally {
        client.release();
      }
    }

    const allowed = ['department', 'location', 'status', 'tags'];
    for (const field of ['purchase_date', 'warranty_end_date']) {
      if (field in body) {
        const value = body[field];
        if (value !== null && (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(Date.parse(`${value}T00:00:00Z`)))) {
          return res.status(400).json({ error: `${field === 'purchase_date' ? 'Purchase' : 'Warranty end'} date must be a valid YYYY-MM-DD date.` });
        }
        allowed.push(field);
      }
    }
    const updates = [];
    const values = [];
    let i = 1;
    for (const k of allowed) {
      if (k in body) {
        updates.push(`${k} = $${i++}`);
        values.push(body[k]);
      }
    }
    if ('warranty_end_date' in body) updates.push('warranty_checked_at = NOW()');
    if (!updates.length) return res.json({ ok: true });
    updates.push('updated_at = NOW()');
    values.push(req.params.id);
    await query(
      `UPDATE assets SET ${updates.join(', ')} WHERE id = $${i}`,
      values
    );
    res.json({ ok: true });
  })
);

/**
 * ADMIN: Delete asset.
 */
router.delete(
  '/:id',
  requireAuth,
  requirePermission('assets', 'delete'),
  asyncHandler(async (req, res) => {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const { rows: assetRows } = await client.query('SELECT * FROM assets WHERE id = $1 FOR UPDATE', [req.params.id]);
      if (!assetRows.length) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: 'Asset not found' });
      }
      const asset = assetRows[0];
      const [software, metrics, alerts, assignments, jobs, discoveries] = await Promise.all([
        client.query('SELECT * FROM installed_software WHERE asset_id = $1', [req.params.id]),
        client.query('SELECT * FROM asset_metrics WHERE asset_id = $1 ORDER BY time', [req.params.id]),
        client.query('SELECT * FROM alerts WHERE asset_id = $1 ORDER BY created_at', [req.params.id]),
        client.query('SELECT * FROM asset_assignment_history WHERE asset_id = $1 ORDER BY occurred_at', [req.params.id]),
        client.query('SELECT * FROM software_deployment_jobs WHERE asset_id = $1 ORDER BY created_at', [req.params.id]),
        client.query('SELECT * FROM network_discoveries WHERE observer_asset_id = $1 ORDER BY last_seen', [req.params.id]),
      ]);
      const snapshot = { asset, software: software.rows, metrics: metrics.rows, alerts: alerts.rows,
        assignment_history: assignments.rows, software_deployment_jobs: jobs.rows, network_discoveries: discoveries.rows };
      await client.query(
        `INSERT INTO deleted_assets (original_asset_id, hostname, asset_tag, deleted_by, deleted_by_email, snapshot)
         VALUES ($1, $2, $3, $4, $5, $6::jsonb)`,
        [asset.id, asset.hostname, asset.asset_tag, req.user.id, req.user.email || null, JSON.stringify(snapshot)]
      );
      await client.query('DELETE FROM assets WHERE id = $1', [req.params.id]);
      await client.query('INSERT INTO audit_log (user_id, action, entity_type, entity_id, payload, ip_address) VALUES ($1, $2, $3, $4, $5::jsonb, $6)',
        [req.user.id, 'asset.deleted', 'asset', asset.id, JSON.stringify({ hostname: asset.hostname, asset_tag: asset.asset_tag }), req.ip]);
      await client.query('COMMIT');
      res.json({ ok: true });
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  })
);

export default router;
