import { z } from 'zod';

export const permissionModules = [
  { key: 'dashboard', label: 'Dashboard' },
  { key: 'assets', label: 'Assets' },
  { key: 'deleted_assets', label: 'Deleted assets' },
  { key: 'asset_tags', label: 'Asset tags' },
  { key: 'software', label: 'Software' },
  { key: 'alerts', label: 'Alerts' },
  { key: 'reports', label: 'Reports' },
  { key: 'users', label: 'Users directory' },
  { key: 'assignments', label: 'Assignments' },
  { key: 'deployments', label: 'Software deployment' },
  { key: 'network_discovery', label: 'Network discovery' },
  { key: 'sites', label: 'Sites' },
];

const permissionActions = z.object({
  read: z.boolean(),
  write: z.boolean(),
  delete: z.boolean(),
}).strict().superRefine((actions, context) => {
  if ((actions.write || actions.delete) && !actions.read) {
    context.addIssue({ code: 'custom', message: 'Write and delete access require read access.' });
  }
});

export const roleSchema = z.object({
  name: z.string().trim().min(2).max(64),
  permissions: z.object(Object.fromEntries(
    permissionModules.map(({ key }) => [key, permissionActions])
  )).strict(),
}).strict();

export function hasPermission(permissions, module, action = 'read') {
  return Boolean(permissions?.[module]?.[action]);
}

export async function ensurePortalAccessSchema(query) {
  const defaultPermissions = Object.fromEntries(permissionModules.map(({ key }) => [
    key,
    { read: ['dashboard', 'assets', 'software', 'alerts', 'reports'].includes(key), write: false, delete: false },
  ]));
  await query(`
    CREATE TABLE IF NOT EXISTS portal_roles (
      id SERIAL PRIMARY KEY,
      name VARCHAR(64) NOT NULL UNIQUE,
      permissions JSONB NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS sites (
      id SERIAL PRIMARY KEY,
      name VARCHAR(100) NOT NULL UNIQUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS site_subnets (
      id BIGSERIAL PRIMARY KEY,
      site_id INTEGER NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
      subnet CIDR NOT NULL,
      UNIQUE (site_id, subnet)
    );
    CREATE INDEX IF NOT EXISTS idx_site_subnets_network ON site_subnets USING GIST (subnet inet_ops);
    ALTER TABLE users ADD COLUMN IF NOT EXISTS role_id INTEGER REFERENCES portal_roles(id) ON DELETE SET NULL;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE;
    INSERT INTO portal_roles (name, permissions)
      VALUES ('Read only', '${JSON.stringify(defaultPermissions)}'::jsonb)
      ON CONFLICT (name) DO NOTHING;
    UPDATE users SET role_id = (SELECT id FROM portal_roles WHERE name = 'Read only')
      WHERE role <> 'admin' AND role_id IS NULL;
  `);
}
