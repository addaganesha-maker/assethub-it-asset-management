import { readFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import nodemailer from 'nodemailer';
import PDFDocument from 'pdfkit';

const plantAddress = '#167, Madhavaram Village, Mantralayam Mandal, Kurnool Dist-518349, (A.P), India.';
const companyLogo = readFileSync(new URL('../assets/mippl-logo.png', import.meta.url));

function display(value) {
  return value === null || value === undefined ? '' : String(value);
}

function addPageIfNeeded(doc, height) {
  if (doc.y + height > doc.page.height - doc.page.margins.bottom) doc.addPage();
}

function addFormTable(doc, rows, columnWidths) {
  const padding = 6;
  for (const row of rows) {
    const cells = row.map((cell) =>
      cell && typeof cell === 'object' ? { ...cell, span: cell.span || 1 } : { value: display(cell), span: 1 }
    );
    const cellHeights = cells.map((cell, index) => {
      const span = cell.span || 1;
      const width = columnWidths.slice(index, index + span).reduce((sum, item) => sum + item, 0) - padding * 2;
      doc.font(cell.bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(cell.fontSize || 11);
      return doc.heightOfString(display(cell.value), { width, lineGap: 1 }) + padding * 2;
    });
    const height = Math.max(24, ...cellHeights);
    addPageIfNeeded(doc, height + 2);
    const top = doc.y;
    let left = doc.page.margins.left;
    let column = 0;
    cells.forEach((cell) => {
      const span = cell.span || 1;
      const width = columnWidths.slice(column, column + span).reduce((sum, item) => sum + item, 0);
      doc.rect(left, top, width, height).lineWidth(0.5).strokeColor('#64748b').stroke();
      doc.font(cell.bold ? 'Helvetica-Bold' : 'Helvetica')
        .fontSize(cell.fontSize || 9)
        .fillColor('#0f172a')
        .text(display(cell.value), left + padding, top + padding, {
          width: width - padding * 2,
          lineGap: 1,
          height: height - padding * 2,
        });
      left += width;
      column += span;
    });
    doc.y = top + height;
  }
  doc.x = doc.page.margins.left;
  doc.y += 5;
}

export function assignmentPolicyFileName(snapshot) {
  const clean = (value) => String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .replace(/[^a-z0-9_-]+/gi, '_')
    .replace(/^_+|_+$/g, '');
  const employee = clean(snapshot.employee.full_name) || 'Employee';
  const asset = clean(snapshot.asset.asset_tag || snapshot.asset.hostname) || 'Asset';
  return `Asset-Policy-${employee}-${asset}.pdf`;
}

function formatAllocationDate(value) {
  return new Date(value).toLocaleDateString('en-GB', {
    timeZone: 'Asia/Kolkata',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).replaceAll('/', '.');
}

export function createAssignmentPolicyPdf(snapshot) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margins: { top: 38, right: 72, bottom: 42, left: 72 } });
    const chunks = [];
    doc.on('data', (chunk) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    const contentWidth = doc.page.width - doc.page.margins.left - doc.page.margins.right;
    const addPlantLocation = () => {
      const { x, y } = doc;
      doc.save();
      doc.font('Helvetica').fontSize(7).fillColor('#475569')
        .text(`Plant Location: ${plantAddress}`, 72, doc.page.height - 28, {
          width: contentWidth,
          align: 'center',
          height: 14,
        });
      doc.restore();
      doc.x = x;
      doc.y = y;
    };
    const addPageBorder = () => {
      const inset = (5 * 72) / 25.4;
      doc.save();
      doc.rect(
        inset,
        inset,
        doc.page.width - inset * 2,
        doc.page.height - inset * 2
      ).lineWidth(3).strokeColor('#000000').stroke();
      doc.restore();
    };
    doc.on('pageAdded', addPageBorder);
    doc.on('pageAdded', addPlantLocation);
    addPageBorder();
    addPlantLocation();
    doc.image(companyLogo, 18, 10, { width: 120, height: 70, fit: [120, 70] });
    doc.font('Helvetica-Bold').fontSize(18).fillColor('#0018a3')
      .text('Maruti Ispat and Pipes Private Limited', doc.page.margins.left, 42, {
        width: contentWidth,
        align: 'center',
        lineBreak: false,
      });
    doc.y = 64;
    doc.font('Helvetica-Bold').fontSize(12).fillColor('#0f172a')
      .text('Laptop Policy Agreement Form', { align: 'center', underline: true });
    doc.moveDown(0.6);

    addFormTable(doc, [
      ['Employee Name:', snapshot.employee.full_name, 'Employee No:', snapshot.employee.employee_id],
      ['Department:', snapshot.employee.department, 'Designation:', snapshot.employee.job_title],
      ['Division:', snapshot.employee.division , 'Mobile No:', snapshot.employee.phone],
    ].map((row) => row.map((value, index) => ({ value, bold: index % 2 === 0, fontSize: 11 }))), [106.1, 134.65, 99.2, 110.85]);

    const introduction = 'With regard to the content of the title, depending on the nature of the work and responsibility, MIPPL as a company has decided to offer you an official Laptop, which should perform only day-to-day operations for official purposes.';
    doc.font('Helvetica').fontSize(11).fillColor('#0f172a')
      .text(introduction, { width: contentWidth, align: 'justify', lineGap: 2 });
    doc.moveDown(0.5);

    const storageType = snapshot.asset.storage_devices?.find((device) =>
      device.media_type && device.media_type.toLowerCase() !== 'unknown'
    )?.media_type;
    const storage = snapshot.asset.disk_total_gb
      ? `${snapshot.asset.disk_total_gb} ${storageType || 'GB'}`
      : '';
    const configurationDetails = [
      [snapshot.asset.os_name, snapshot.asset.os_version, snapshot.asset.os_build].filter(Boolean).join(' '),
      snapshot.asset.ram_gb ? `${snapshot.asset.ram_gb}GB` : '',
      storage,
    ].filter(Boolean).join('/');
    const configuration = [
      snapshot.asset.cpu_model,
      configurationDetails ? `(${configurationDetails})` : '',
    ].filter(Boolean).join('-');
    addFormTable(doc, [
      ['Laptop Serial No.:', snapshot.asset.serial_number, 'Asset Code:', snapshot.asset.asset_tag],
      ['Product ID:', snapshot.asset.product_id, 'Date of Allocation:', formatAllocationDate(snapshot.issued_at)],
      ['Laptop Make/Model:', [snapshot.asset.manufacturer, snapshot.asset.model].filter(Boolean).join(' '), 'New /Replaced:', snapshot.issue_condition],
      ['Charger:', snapshot.charger, { value: `Configuration: ${configuration}`, span: 2, bold: true, fontSize: 8.5 }],
      ['Mouse:', snapshot.mouse, { value: '', span: 2 }],
    ].map((row) => row.map((cell, index) => typeof cell === 'string'
      ? { value: cell, bold: index === 0 || index === 2, fontSize: 9.5 }
      : cell)), [120.25, 120.5, 97.35, 112.7]);

    const policyParagraphs = [
      'I understand that all Laptop, equipment and accessories that MIPPL has provided me are the property of MIPPL.',

      'I agree with and will adhere to all of the aforementioned rules and guidelines.',

      'I understand that I am financially responsible for any damage to or loss of the laptop, equipment and accessories. In case of damage or loss I will replace or pay the full cost of replacement of the damaged or lost equipment with equipment of equal value and functionality subject to the approval of MIPPL.',

      'I will not install any additional software or change the configuration of the equipment in the anyway. I will not allow any other individuals to use the laptop issued to me and/or the related equipment and accessories that have been provided to me by MIPPL.',

      'I agree to adhere to all MIPPL guidelines regarding patient information.',

      "I agree to return the laptop and accessories in my possession immediately upon termination or in the alternative; MIPPL may withhold the replacement cost of the laptop/accessories from my last pay-cheque. I will report damage or suspected problems immediately to MIPPL IT Department. I will not use the laptop/accessories for personal use.",

      'I understand that a violation of the terms and conditions set out in the policy will result in the restriction and/or termination of my use of MIPPL Laptop, equipment and accessories and may result in further discipline up to and including termination of employment and/or other legal action.',
    ];
    policyParagraphs.forEach((paragraph) => {
      const height = doc.heightOfString(paragraph, { width: contentWidth, lineGap: 1, fontSize: 12 });
      addPageIfNeeded(doc, height + 7);
      doc.font('Helvetica').fontSize(11).fillColor('#0f172a')
        .text(paragraph, { width: contentWidth, align: 'justify', lineGap: 1 });
      doc.moveDown(0.15);
    });

    addPageIfNeeded(doc, 80);
    doc.moveDown(0.3);
    addFormTable(doc, [
      [{ value: 'IT-Department', bold: true, fontSize: 10 }, { value: 'HR-Department', bold: true, fontSize: 10 }, { value: 'Employee Signature', bold: true, fontSize: 10 }],
      ['Signature', 'Signature', 'Signature'],
      ['Date:', 'Date:', 'Date:'],
    ], [153.4, 150.1, 150.1]);
    doc.end();
  });
}

function assignmentPolicyEmailContent(snapshot) {
  const assetCode = snapshot.asset.asset_tag || snapshot.asset.asset_tags?.join(', ');
  const assetName = [assetCode, snapshot.asset.hostname].filter(Boolean).join(' - ');
  const escapeHtml = (value) => String(value || '').replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character]);
  const systemDetails = [
    ['Asset type', snapshot.asset.asset_type],
    ['Hostname', snapshot.asset.hostname],
    ['Asset code', snapshot.asset.asset_tag || snapshot.asset.asset_tags?.join(', ')],
    ['Make / model', [snapshot.asset.manufacturer, snapshot.asset.model].filter(Boolean).join(' ')],
    ['Serial number', snapshot.asset.serial_number],
    ['Processor', snapshot.asset.cpu_model],
    ['Operating system', [snapshot.asset.os_name, snapshot.asset.os_version, snapshot.asset.os_build].filter(Boolean).join(' ')],
    ['Memory', snapshot.asset.ram_gb ? `${snapshot.asset.ram_gb} GB` : ''],
    ['Storage', snapshot.asset.disk_total_gb ? `${snapshot.asset.disk_total_gb} GB` : ''],
  ].filter(([, value]) => value);
  const htmlDetails = systemDetails.map(([label, value]) =>
    `<strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}`
  ).join('<br>');

  return {
    to: snapshot.employee.email,
    subject: `MIPPL asset assigned to you: ${assetName}`,
    html: `<p>Dear ${escapeHtml(snapshot.employee.full_name)},</p><p>A ${escapeHtml(snapshot.asset.asset_type || 'laptop')} has been assigned to you.</p><p><strong>System details:</strong><br>${htmlDetails}</p><p>Please find your asset policy agreement attached. Kindly review, sign, and return it to the IT/HR departments.</p><p>Regards,<br>MIPPL IT Department</p>`,
  };
}

function returnPolicyFileName(snapshot) {
  const clean = (value) => String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .replace(/[^a-z0-9_-]+/gi, '_')
    .replace(/^_+|_+$/g, '');
  const employee = clean(snapshot.employee.full_name) || 'Employee';
  const asset = clean(snapshot.asset.asset_tag || snapshot.asset.hostname) || 'Asset';
  return `Asset-Return-Policy-${employee}-${asset}.pdf`;
}

export const RETURN_CHECKLIST_DEFAULTS = [
  'Mobile / Tab',
  'Keyboard & Mouse',
  'Monitor',
  'IP-Phone',
  'Laptop / Desktop',
  'Charger',
  'Colour Printer Access',
  'Wi-Fi Access (Employee)',
  'Wi-Fi Access in Phone',
  'Pen drive Access',
  'Other Than ASL (Software List)',
  'Access to Confidential Data / Mail / Mail Forwarding',
  'Mail Access',
  'Others (If Any)',
];

export function createReturnPolicyPdf(snapshot) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margins: { top: 40, right: 50, bottom: 40, left: 50 } });
    const chunks = [];
    doc.on('data', (chunk) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    const pageWidth = doc.page.width;
    const left = 50;
    const contentWidth = pageWidth - 100;
    const returnSection = snapshot.return_section ? snapshot.return_section.charAt(0).toUpperCase() + snapshot.return_section.slice(1) : 'Main';
    const employeeName = snapshot.employee?.full_name || 'Employee';
    const employeeId = snapshot.employee?.employee_id || '—';
    const department = snapshot.employee?.department || '—';
    const assetCode = snapshot.asset.asset_tag || snapshot.asset.asset_tags?.join(', ');
    const hostname = snapshot.asset?.hostname || '—';
    const makeModel = [snapshot.asset?.manufacturer, snapshot.asset?.model].filter(Boolean).join(' ') || '—';
    const serialNo = snapshot.asset?.serial_number || '—';
    const returnDate = formatAllocationDate(snapshot.last_working_date || snapshot.returned_at || new Date().toISOString());
    const checklistRows = Array.isArray(snapshot.checklist)
      ? snapshot.checklist.slice(0, RETURN_CHECKLIST_DEFAULTS.length)
      : RETURN_CHECKLIST_DEFAULTS.map((item) => ({ item, applicable: false, returned: false, remarks: '' }));

    doc.rect(35, 25, pageWidth - 70, doc.page.height - 50).lineWidth(2).strokeColor('#111827').stroke();
    doc.image(companyLogo, left + 8, 30, { width: 110, height: 90, fit: [110, 90] });
        doc.font('Helvetica-Bold').fontSize(15).fillColor('#0f57f3').text('Maruti Ispat and Pipes Private Limited', left + 135, 49, { width: 330, lineBreak: false, ellipsis: true });
    doc.font('Helvetica-Bold').fontSize(12).fillColor('#111827').text('IT Asset Return Format', 0, 82, { align: 'center' });

    const drawField = (label, value, x, y, labelWidth, valueWidth) => {
      doc.font('Helvetica-Bold').fontSize(10).fillColor('#111827').text(label, x, y, { width: labelWidth });
      doc.font('Helvetica').fontSize(10).fillColor('#111827').text(value || '—', x + labelWidth, y, { width: valueWidth, lineBreak: false, ellipsis: true });
    };

    doc.rect(left, 96, contentWidth, 68).lineWidth(1.2).strokeColor('#000c08').stroke();
    doc.moveTo(left, 130).lineTo(left + contentWidth, 130).lineWidth(1).strokeColor('#080405').stroke();
    drawField('Department:', department, left + 15, 106, 70, 150);
    drawField('Employee Name:', employeeName, left + 230, 106, 88, 155);
    drawField('Employee No:', employeeId, left + 15, 140, 70, 150);
    drawField('Last Working Date:', returnDate, left + 230, 140, 92, 140);

      doc.font('Helvetica-Bold').fontSize(9.5).fillColor('#111827').text('Purpose', left + 9, 172);
    doc.font('Helvetica').fontSize(8).fillColor('#111827').text(
      'The purpose of the IT Asset Return Checklist is to ensure that all hardware, software, and digital access rights provided to an employee during their tenure are properly returned, accounted for, and deactivated upon their exit (resignation, termination, or transfer). This process safeguards the company’s assets, prevents unauthorized access to systems and data, and facilitates a smooth and secure offboarding procedure.',
      left + 9, 185, { width: contentWidth - 18, align: 'justify', lineGap: 2 }
    );
        
    doc.font('Helvetica-Bold').fontSize(9.5).fillColor('#111827').text('Scope', left + 9, 240);
    doc.font('Helvetica').fontSize(8).fillColor('#111827').text(
      'This checklist applies to all employees, interns, contractors, and consultants of Maruti Ispat and Pipes Pvt. Ltd. who have been issued IT assets or granted access to IT systems during their employment. It covers return and verification of physical devices, accessories, software licenses, and deactivation of user accounts upon resignation, termination, internal transfer, or completion of contract.',
      left + 9, 253, { width: contentWidth - 18, align: 'justify', lineGap: 2 }
    );

    drawField('Make / Model:', makeModel, left + 8, 315, 74, 166);
    drawField('Hostname:', hostname, left + 260, 315, 52, 170);
    drawField('Serial No:', serialNo, left + 8, 330, 74, 166);
    drawField('Returned to:', `${returnSection} stock`, left + 260, 330, 62, 164);

    doc.font('Helvetica-Bold').fontSize(11).fillColor('#111827').text('Check List', 0, 363, { align: 'center' });
    const tableLeft = left;
    const tableTop = 380;
    const colWidths = [32, 167, 67, 100, 129];
    const headerHeight = 25;
    const rowHeight = 19;
    const headerLabels = ['SNo', 'Assets / Access Item', 'Applicable', 'Return / De-activated', 'Remarks'];
    let xPos = tableLeft;
    headerLabels.forEach((label, index) => {
      const width = colWidths[index];
      doc.rect(xPos, tableTop, width, headerHeight).lineWidth(0.8).strokeColor('#111827').stroke();
      doc.font('Helvetica-Bold').fontSize(7).fillColor('#111827')
        .text(label, xPos + 3, tableTop + 4, { width: width - 6, height: headerHeight - 6, align: 'center', valign: 'center' });
      xPos += width;
    });

    checklistRows.forEach((row, rowIndex) => {
      const y = tableTop + headerHeight + (rowIndex * rowHeight);
      let x = tableLeft;
      colWidths.forEach((width) => {
        doc.rect(x, y, width, rowHeight).lineWidth(0.7).strokeColor('#111827').stroke();
        x += width;
      });

      doc.font('Helvetica').fontSize(7.2).fillColor('#111827')
        .text(String(rowIndex + 1), tableLeft + 3, y + 5, { width: colWidths[0] - 6, align: 'center', lineBreak: false });
      doc.font('Helvetica').fontSize(6.8).fillColor('#111827')
        .text(String(row.item || ''), tableLeft + colWidths[0] + 5, y + 5, { width: colWidths[1] - 10, lineBreak: false, ellipsis: true });

      const applicableX = tableLeft + colWidths[0] + colWidths[1] + Math.floor((colWidths[2] - 11) / 2);
      const returnedX = tableLeft + colWidths[0] + colWidths[1] + colWidths[2] + Math.floor((colWidths[3] - 11) / 2);
      const checkY = y + 4;
      doc.rect(applicableX, checkY, 11, 11).lineWidth(0.8).strokeColor('#111827').stroke();
      doc.rect(returnedX, checkY, 11, 11).lineWidth(0.8).strokeColor('#111827').stroke();
      if (row.applicable) {
        doc.lineWidth(1.4).strokeColor('#111827').moveTo(applicableX + 2, checkY + 6).lineTo(applicableX + 4.5, checkY + 9).lineTo(applicableX + 9, checkY + 2).stroke();
      }
      if (row.returned) {
        doc.lineWidth(1.4).strokeColor('#111827').moveTo(returnedX + 2, checkY + 6).lineTo(returnedX + 4.5, checkY + 9).lineTo(returnedX + 9, checkY + 2).stroke();
      }
      const remarksX = tableLeft + colWidths.slice(0, 4).reduce((sum, width) => sum + width, 0);
      doc.font('Helvetica').fontSize(6.8).fillColor('#111827')
        .text(String(row.remarks || ''), remarksX + 4, y + 5, { width: colWidths[4] - 8, lineBreak: false, ellipsis: true });
    });

    const footerY = tableTop + headerHeight + (RETURN_CHECKLIST_DEFAULTS.length * rowHeight) + 18;
    doc.rect(left, footerY, contentWidth, 74).lineWidth(1).strokeColor('#111827').stroke();
    const signWidth = 145;
    const signCols = [left + 8, left + 175, left + 342];
    const signLabels = ['Checked By', 'Reviewed By', 'Approved By'];
    signLabels.forEach((label, index) => {
      const x = signCols[index];
      doc.font('Helvetica-Bold').fontSize(8.5).fillColor('#111827').text(label, x + 28, footerY + 8);
      doc.rect(x, footerY + 24, signWidth, 19).lineWidth(0.8).strokeColor('#111827').stroke();
      doc.rect(x, footerY + 46, signWidth, 19).lineWidth(0.8).strokeColor('#111827').stroke();
      doc.font('Helvetica').fontSize(7.5).fillColor('#111827').text('Signature:', x + 7, footerY + 30);
      doc.text('Date:', x + 7, footerY + 52);
    });

    doc.end();
  });
}

function parseEmailList(value) {
  return [...new Set(
    String(value || '')
      .split(/[;,]/)
      .map((entry) => entry.trim())
      .filter((entry) => entry && /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(entry))
  )];
}

function emailRecipientsForPolicy(snapshot) {
  const userEmail = String(snapshot.employee?.email || '').trim();
  const hrEmails = [
    process.env.HR_EMAIL,
    process.env.HR_EMAILS,
    process.env.HR_DEPARTMENT_EMAIL,
    process.env.RETURN_POLICY_HR_EMAIL,
  ].flatMap((entry) => parseEmailList(entry));
  const recipients = [...new Set([userEmail, ...hrEmails].filter(Boolean))];
  return {
    to: recipients.length ? recipients[0] : '',
    cc: recipients.length > 1 ? recipients.slice(1) : [],
    all: recipients,
  };
}

export async function sendReturnPolicyEmail(snapshot, pdf) {
  const assetName = [snapshot.asset.asset_tag, snapshot.asset.hostname].filter(Boolean).join(' - ');
  const returnSection = snapshot.return_section ? snapshot.return_section.charAt(0).toUpperCase() + snapshot.return_section.slice(1) : 'Main';
  const { to, cc, all } = emailRecipientsForPolicy(snapshot);
  if (!all.length) {
    const error = new Error('The assigned employee and HR department do not have valid email addresses configured.');
    error.code = 'EMAIL_NOT_CONFIGURED';
    throw error;
  }

  const host = String(process.env.SMTP_HOST || '').trim();
  const from = String(process.env.SMTP_FROM || '').trim();
  if (!host || !from) {
    const error = new Error('Email is not configured. Set SMTP_HOST and SMTP_FROM in the server environment.');
    error.code = 'EMAIL_NOT_CONFIGURED';
    throw error;
  }

  const smtpUser = String(process.env.SMTP_USER || '').trim();
  const smtpPass = String(process.env.SMTP_PASS || '').trim();
  if ((smtpUser || smtpPass) && !(smtpUser && smtpPass)) {
    const error = new Error('Incomplete SMTP authentication configuration. Set both SMTP_USER and SMTP_PASS.');
    error.code = 'EMAIL_NOT_CONFIGURED';
    throw error;
  }

  const port = Number(process.env.SMTP_PORT || 587);
  const secure = process.env.SMTP_SECURE === 'true';
  const auth = smtpUser && smtpPass ? { user: smtpUser, pass: smtpPass } : undefined;
  const smtpDebug = String(process.env.SMTP_DEBUG || '').toLowerCase() === 'true';
  const allowSelfSigned = String(process.env.SMTP_ALLOW_SELF_SIGNED || '').toLowerCase() === 'true';
  const transporter = nodemailer.createTransport({
    host,
    port,
    secure,
    requireTLS: !secure && process.env.SMTP_REQUIRE_TLS !== 'false',
    auth,
    logger: smtpDebug,
    debug: smtpDebug,
    tls: allowSelfSigned ? { rejectUnauthorized: false } : undefined,
  });

  try {
    await transporter.verify();
  } catch (err) {
    const error = new Error(`Unable to verify SMTP connection: ${err && err.message ? err.message : String(err)}`);
    error.code = 'SMTP_VERIFY_FAILED';
    error.original = err;
    throw error;
  }

  try {
    await transporter.sendMail({
      from,
      to,
      cc: cc.length ? cc : undefined,
      subject: `MIPPL asset return acknowledgement: ${assetName}`,
      html: `<p>Dear ${snapshot.employee.full_name || 'Employee'},</p><p>This is to acknowledge that the asset <strong>${assetName}</strong> has been returned to the IT department and placed in the ${returnSection} stock section.</p><p>Please review the attached return policy acknowledgement and keep a copy for your records.</p><p>Regards,<br>MIPPL IT Department</p>`,
      attachments: [{ filename: returnPolicyFileName(snapshot), content: pdf, contentType: 'application/pdf' }],
    });
  } catch (err) {
    const error = new Error(`Failed to send asset return policy email: ${err && err.message ? err.message : String(err)}`);
    error.code = 'SMTP_SEND_FAILED';
    error.original = err;
    throw error;
  }
}

export function createAssignmentPolicyOutlookDraft(snapshot, pdf) {
  const { to, subject, html } = assignmentPolicyEmailContent(snapshot);
  if (!to || !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(to)) {
    throw new Error('The assigned employee does not have a valid email address.');
  }
  const boundary = `assethub-${randomUUID()}`;
  const encodedSubject = Buffer.from(subject, 'utf8').toString('base64');
  const htmlBase64 = Buffer.from(html, 'utf8').toString('base64').match(/.{1,76}/g).join('\r\n');
  const pdfBase64 = pdf.toString('base64').match(/.{1,76}/g).join('\r\n');
  const fileName = assignmentPolicyFileName(snapshot);
  return [
    `To: ${to}`,
    `Subject: =?UTF-8?B?${encodedSubject}?=`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/mixed; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    'Content-Type: text/html; charset="UTF-8"',
    'Content-Transfer-Encoding: base64',
    '',
    htmlBase64,
    `--${boundary}`,
    'Content-Type: application/pdf; name="' + fileName + '"',
    'Content-Transfer-Encoding: base64',
    `Content-Disposition: attachment; filename="${fileName}"`,
    '',
    pdfBase64,
    `--${boundary}--`,
    '',
  ].join('\r\n');
}

export function createAssignmentPolicyOutlookPayload(snapshot, pdf) {
  const { to, subject, html } = assignmentPolicyEmailContent(snapshot);
  if (!to || !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(to)) {
    throw new Error('The assigned employee does not have a valid email address.');
  }
  return {
    to,
    subject,
    html,
    filename: assignmentPolicyFileName(snapshot),
    pdf_base64: pdf.toString('base64'),
  };
}

export async function sendAssignmentPolicyEmail(snapshot, pdf) {
  const { to, subject, html } = assignmentPolicyEmailContent(snapshot);
  const cc = parseEmailList([process.env.HR_EMAIL, process.env.HR_EMAILS, process.env.HR_DEPARTMENT_EMAIL].join(','));
  const host = String(process.env.SMTP_HOST || '').trim();
  const from = String(process.env.SMTP_FROM || '').trim();
  if (!host || !from) {
    const error = new Error('Email is not configured. Set SMTP_HOST and SMTP_FROM in the server environment.');
    error.code = 'EMAIL_NOT_CONFIGURED';
    throw error;
  }

  const smtpUser = String(process.env.SMTP_USER || '').trim();
  const smtpPass = String(process.env.SMTP_PASS || '').trim();
  if ((smtpUser || smtpPass) && !(smtpUser && smtpPass)) {
    const error = new Error('Incomplete SMTP authentication configuration. Set both SMTP_USER and SMTP_PASS.');
    error.code = 'EMAIL_NOT_CONFIGURED';
    throw error;
  }

  const port = Number(process.env.SMTP_PORT || 587);
  const secure = process.env.SMTP_SECURE === 'true';
  const auth = smtpUser && smtpPass ? { user: smtpUser, pass: smtpPass } : undefined;

  const smtpDebug = String(process.env.SMTP_DEBUG || '').toLowerCase() === 'true';
  const allowSelfSigned = String(process.env.SMTP_ALLOW_SELF_SIGNED || '').toLowerCase() === 'true';

  const transporter = nodemailer.createTransport({
    host,
    port,
    secure,
    requireTLS: !secure && process.env.SMTP_REQUIRE_TLS !== 'false',
    auth,
    logger: smtpDebug,
    debug: smtpDebug,
    tls: allowSelfSigned ? { rejectUnauthorized: false } : undefined,
  });

  try {
    await transporter.verify();
  } catch (err) {
    const error = new Error(`Unable to verify SMTP connection: ${err && err.message ? err.message : String(err)}`);
    error.code = 'SMTP_VERIFY_FAILED';
    error.original = err;
    throw error;
  }

  try {
    await transporter.sendMail({
      from,
      to,
      cc: cc.length ? cc : undefined,
      subject,
      html,
      attachments: [{ filename: assignmentPolicyFileName(snapshot), content: pdf, contentType: 'application/pdf' }],
    });
  } catch (err) {
    const error = new Error(`Failed to send assignment policy email: ${err && err.message ? err.message : String(err)}`);
    error.code = 'SMTP_SEND_FAILED';
    error.original = err;
    throw error;
  }
}
