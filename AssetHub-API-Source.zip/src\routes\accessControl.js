import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { query } from '../config/db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/error.js';
import { roleSchema } from '../services/portalAccess.js';

const router = Router();
const accountSchema = z.object({
  email: z.string().trim().email().max(255).transform((email) => email.toLowerCase()),
  full_name: z.string().trim().min(1).max(128),
  password: z.string().min(12).max(128),
  role_id: z.number().int().positive(),
});

router.use(requireAuth, requireRole('admin'));

router.get('/', asyncHandler(async (_req, res) => {
  const [roles, accounts] = await Promise.all([
    query('SELECT id, name, permissions, created_at FROM portal_roles ORDER BY LOWER(name)'),
    query(`SELECT u.id, u.email, u.full_name, u.role, u.auth_provider, u.is_active,
                  u.created_at, u.last_login, u.role_id, r.name AS role_name
           FROM users u LEFT JOIN portal_roles r ON r.id = u.role_id
           ORDER BY u.created_at DESC`),
  ]);
  res.json({ roles: roles.rows, accounts: accounts.rows });
}));

router.post('/roles', asyncHandler(async (req, res) => {
  const parsed = roleSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid role.' });
  try {
    const { rows } = await query(
      'INSERT INTO portal_roles (name, permissions) VALUES ($1, $2::jsonb) RETURNING id, name, permissions, created_at',
      [parsed.data.name, JSON.stringify(parsed.data.permissions)]
    );
    res.status(201).json(rows[0]);
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'A role with this name already exists.' });
    throw error;
  }
}));

router.patch('/roles/:id', asyncHandler(async (req, res) => {
  if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid role ID.' });
  const parsed = roleSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid role.' });
  try {
    const { rows } = await query(
      `UPDATE portal_roles SET name = $1, permissions = $2::jsonb, updated_at = NOW()
       WHERE id = $3 RETURNING id, name, permissions, created_at`,
      [parsed.data.name, JSON.stringify(parsed.data.permissions), req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Role not found.' });
    res.json(rows[0]);
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'A role with this name already exists.' });
    throw error;
  }
}));

router.delete('/roles/:id', asyncHandler(async (req, res) => {
  if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid role ID.' });
  const { rows: assigned } = await query('SELECT 1 FROM users WHERE role_id = $1 LIMIT 1', [req.params.id]);
  if (assigned.length) return res.status(409).json({ error: 'Reassign all portal accounts before deleting this role.' });
  const { rowCount } = await query('DELETE FROM portal_roles WHERE id = $1', [req.params.id]);
  if (!rowCount) return res.status(404).json({ error: 'Role not found.' });
  res.json({ ok: true });
}));

router.post('/accounts', asyncHandler(async (req, res) => {
  const parsed = accountSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid portal account.' });
  const { rows: roleRows } = await query('SELECT id FROM portal_roles WHERE id = $1', [parsed.data.role_id]);
  if (!roleRows.length) return res.status(400).json({ error: 'Choose a valid access role.' });
  try {
    const passwordHash = await bcrypt.hash(parsed.data.password, 12);
    const { rows } = await query(
      `INSERT INTO users (email, password_hash, full_name, role, role_id, auth_provider)
       VALUES ($1, $2, $3, 'viewer', $4, 'local')
       RETURNING id, email, full_name, role, role_id, is_active, created_at`,
      [parsed.data.email, passwordHash, parsed.data.full_name, parsed.data.role_id]
    );
    res.status(201).json(rows[0]);
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'A portal account already uses this email.' });
    throw error;
  }
}));

router.patch('/accounts/:id', asyncHandler(async (req, res) => {
  if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid account ID.' });
  const parsed = z.object({ role_id: z.number().int().positive(), is_active: z.boolean() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Choose a role and account status.' });
  if (Number(req.params.id) === req.user.id && !parsed.data.is_active) {
    return res.status(400).json({ error: 'You cannot disable your own account.' });
  }
  const { rows: accountRows } = await query('SELECT id, role, ad_employee_id FROM users WHERE id = $1', [req.params.id]);
  if (!accountRows.length) return res.status(404).json({ error: 'Portal account not found.' });
  if (accountRows[0].role === 'admin' || accountRows[0].ad_employee_id) {
    return res.status(403).json({ error: 'Administrator and Active Directory accounts cannot be changed here.' });
  }
  const { rows: roleRows } = await query('SELECT id FROM portal_roles WHERE id = $1', [parsed.data.role_id]);
  if (!roleRows.length) return res.status(400).json({ error: 'Choose a valid access role.' });
  const { rows } = await query(
    `UPDATE users SET role_id = $1, is_active = $2 WHERE id = $3
     RETURNING id, email, full_name, role, role_id, is_active`,
    [parsed.data.role_id, parsed.data.is_active, req.params.id]
  );
  res.json(rows[0]);
}));

router.patch('/accounts/:id/password', asyncHandler(async (req, res) => {
  if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid account ID.' });
  const parsed = z.object({ password: z.string().min(12).max(128) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Password must be between 12 and 128 characters.' });

  const { rows } = await query('SELECT id, role, auth_provider FROM users WHERE id = $1', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Portal account not found.' });
  if (rows[0].role === 'admin' || rows[0].auth_provider !== 'local') {
    return res.status(403).json({ error: 'Only local Sub-IT portal account passwords can be changed here.' });
  }

  const passwordHash = await bcrypt.hash(parsed.data.password, 12);
  await query('UPDATE users SET password_hash = $1 WHERE id = $2', [passwordHash, req.params.id]);
  res.json({ ok: true });
}));

export default router;
