import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { randomBytes } from 'node:crypto';
import { z } from 'zod';
import { query } from '../config/db.js';
import { asyncHandler } from '../middleware/error.js';
import { authenticateActiveDirectory, isActiveDirectoryConfigured } from '../services/activeDirectory.js';

const router = Router();

const loginSchema = z.object({
  email: z.string().email().optional(),
  username: z.string().trim().min(1).max(255).optional(),
  password: z.string().min(1),
  provider: z.enum(['local', 'active_directory']).default('local'),
});

const adAdminEmployeeIds = new Set(
  (process.env.AD_ADMIN_EMPLOYEE_IDS || '03017').split(',').map((id) => id.trim()).filter(Boolean)
);

async function issueSession(res, user) {
  const { rows: roles } = user.role === 'admin' || !user.role_id
    ? { rows: [] }
    : await query('SELECT name, permissions FROM portal_roles WHERE id = $1', [user.role_id]);
  if (user.role !== 'admin' && !roles.length) {
    return res.status(403).json({ error: 'Your account does not have a valid portal access role.' });
  }
  const token = jwt.sign(
    { id: user.id },
    process.env.JWT_SECRET,
    { expiresIn: '12h' }
  );
  res.json({
    token,
    user: {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.full_name,
      role_id: user.role_id,
      role_name: roles[0]?.name || 'Administrator',
      permissions: roles[0]?.permissions || null,
    },
  });
}

router.get('/config', (_req, res) => {
  res.json({ active_directory: isActiveDirectoryConfigured() });
});

router.post(
  '/login',
  asyncHandler(async (req, res) => {
    const parsed = loginSchema.parse(req.body);
    const { email, password, provider } = parsed;

    if (provider === 'active_directory') {
      if (!isActiveDirectoryConfigured()) {
        return res.status(503).json({ error: 'Active Directory sign-in is not configured on this server.' });
      }
      let identity;
      try {
        identity = await authenticateActiveDirectory(parsed.username || email || '', password);
      } catch (error) {
        console.error('[auth] Active Directory sign-in unavailable:', error?.name || 'LDAP error');
        return res.status(503).json({ error: 'Active Directory sign-in is temporarily unavailable. Check the server LDAP configuration.' });
      }
      if (!identity) return res.status(401).json({ error: 'Invalid Active Directory credentials or account is not allowed.' });

      const isAdAdmin = adAdminEmployeeIds.has(identity.employeeId);
      const { rows: staffRows } = await query(
        'SELECT status FROM staff_users WHERE employee_id = $1',
        [identity.employeeId]
      );
      if (!isAdAdmin && staffRows[0]?.status !== 'active') {
        return res.status(403).json({ error: 'Your Active Directory account is not enabled in the AssetHub user directory.' });
      }

      const { rows: matches } = await query(
        'SELECT id, email, ad_employee_id, role FROM users WHERE ad_employee_id = $1 OR LOWER(email) = LOWER($2)',
        [identity.employeeId, identity.email]
      );
      if (matches.length > 1 || (matches[0]?.ad_employee_id && matches[0].ad_employee_id !== identity.employeeId)) {
        return res.status(409).json({ error: 'This Active Directory account conflicts with an existing AssetHub login.' });
      }

      const user = matches[0]
        ? (await query(
          `UPDATE users SET email = $1, full_name = $2,
             ad_employee_id = $3, auth_provider = 'active_directory',
             role = CASE WHEN $4 THEN 'admin' ELSE role END,
             role_id = CASE WHEN $4 THEN NULL ELSE COALESCE(role_id, (SELECT id FROM portal_roles WHERE name = 'Read only')) END,
             last_login = NOW()
           WHERE id = $5 RETURNING *`,
          [identity.email, identity.fullName, identity.employeeId, isAdAdmin, matches[0].id]
        )).rows[0]
        : (await query(
          `INSERT INTO users (email, password_hash, full_name, role, role_id, ad_employee_id, auth_provider, last_login)
           VALUES ($1, $2, $3, $4,
             CASE WHEN $4 = 'admin' THEN NULL ELSE (SELECT id FROM portal_roles WHERE name = 'Read only') END,
             $5, 'active_directory', NOW()) RETURNING *`,
          [identity.email, await bcrypt.hash(randomBytes(48).toString('base64url'), 10), identity.fullName, isAdAdmin ? 'admin' : 'viewer', identity.employeeId]
        )).rows[0];

      return issueSession(res, user);
    }

    if (!email) return res.status(400).json({ error: 'Enter your AssetHub email address.' });
    const { rows } = await query('SELECT * FROM users WHERE email = $1 AND is_active = TRUE', [email.toLowerCase()]);
    const user = rows[0];
    if (!user || user.auth_provider === 'active_directory' || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    await query('UPDATE users SET last_login = NOW() WHERE id = $1', [user.id]);
    await issueSession(res, user);
  })
);

export default router;
